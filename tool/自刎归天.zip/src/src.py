﻿import hashlib
import random
import string
import tkinter as tk
from tkinter import messagebox, simpledialog

def generate_activation_code(machine_code):
    """基于机器码生成激活码"""
    seed = hashlib.md5(machine_code.encode()).hexdigest()
    random.seed(seed)
    
    chars = string.ascii_uppercase + string.digits
    parts = []
    for _ in range(4):
        part = ''.join(random.choice(chars) for _ in range(4))
        parts.append(part)
    return '-'.join(parts)

if __name__ == "__main__":
        # 如果 GUI 失败，回退到命令行
        print("=" * 50)
        print("🔐 应用激活码生成器")
        print("=" * 50)
        machine_code = input("\n📋 请输入机器码：").strip().upper()
        if machine_code:
            activation_code = generate_activation_code(machine_code)
            print("\n" + "=" * 50)
            print(f"🔑 激活码：{activation_code}")
            print("=" * 50)
        else:
            print("❌ 机器码不能为空")
        input("\n按回车键退出...")
