"""
Demon Roulette for ESP32 - Ultra Enhanced AI Version
OLED 128x64 SSD1306 (SDA=8, SCL=9), Button=GPIO21
Easy: Harder than before / Hard: Brutal / One-Life: Nearly Unbeatable
Fixed: Empty bullet bug
"""

import machine
import ssd1306
import time
import random
from machine import Pin

# ==================== HARDWARE SETUP ====================
SDA_PIN = 8
SCL_PIN = 9
BTN_PIN = 21

i2c = machine.I2C(0, sda=Pin(SDA_PIN), scl=Pin(SCL_PIN), freq=400000)
oled = ssd1306.SSD1306_I2C(128, 64, i2c)
button = Pin(BTN_PIN, Pin.IN, Pin.PULL_UP)

print("Hardware initialized")

# ==================== UTILITY FUNCTIONS ====================
def shuffle_list(lst):
    for i in range(len(lst)-1, 0, -1):
        j = random.randint(0, i)
        lst[i], lst[j] = lst[j], lst[i]
    return lst

# ==================== GAME STATE ====================
class GameState:
    def __init__(self):
        self.reset()
        self.difficulty = "EASY"
        self.demon_memory = {}  # Demon remembers things between rounds
        
    def reset(self):
        self.round = 1
        self.lives_player = 3
        self.lives_demon = 3
        self.bullets = []
        self.current_bullet_idx = 0
        self.player_turn = True
        self.target_is_demon = True
        self.items = []
        self.demon_items = []
        self.phase = "difficulty_select"
        self.message = ""
        self.item_menu_active = False
        self.selected_item_index = 0
        self.magnify_info = None
        self.demon_magnify_info = None
        self.handcuffs_active = False
        self.player_cuffed = False
        self.game_over = False
        self.difficulty_selected_index = 0
        self.player_used_magnify_recently = False
        self.demon_knows_player_items = False

state = GameState()

# ==================== ITEMS ====================
ITEM_MAGNIFY = 1
ITEM_CIGARETTE = 2
ITEM_BEER = 3
ITEM_HANDCUFFS = 4
ITEM_SAW = 5

ITEM_NAMES = {
    ITEM_MAGNIFY: "MAGNIFY",
    ITEM_CIGARETTE: "CIGARETTE",
    ITEM_BEER: "BEER",
    ITEM_HANDCUFFS: "HANDCUFFS",
    ITEM_SAW: "SAW"
}

ITEM_ICONS = {
    ITEM_MAGNIFY: "?",
    ITEM_CIGARETTE: "+",
    ITEM_BEER: "X",
    ITEM_HANDCUFFS: "=",
    ITEM_SAW: "!"
}

def random_item():
    items = [ITEM_MAGNIFY, ITEM_CIGARETTE, ITEM_BEER, ITEM_HANDCUFFS, ITEM_SAW]
    
    if state.difficulty == "ONE_LIFE":
        if random.random() < 0.92:  # Only 8% chance for cigarette
            items = [ITEM_MAGNIFY, ITEM_BEER, ITEM_HANDCUFFS, ITEM_SAW]
    
    return items[random.randint(0, len(items)-1)]

# ==================== BULLET SYSTEM ====================
def generate_bullets():
    """Generate bullets - harder modes favor the demon"""
    if state.difficulty == "EASY":
        total = random.randint(2, 6)
        live = random.randint(1, total-1)
    elif state.difficulty == "HARD":
        total = random.randint(3, 6)
        live = random.randint(2, total-1)  # More live rounds
    else:  # ONE_LIFE
        total = random.randint(4, 6)
        live = random.randint(3, total-1)  # Even more live rounds
    
    blank = total - live
    bullets = [1] * live + [0] * blank
    return shuffle_list(bullets)

def current_bullet():
    if state.current_bullet_idx < len(state.bullets):
        return state.bullets[state.current_bullet_idx]
    return None

def fire_bullet():
    if len(state.bullets) == 0:
        return -1
    bullet = state.bullets.pop(state.current_bullet_idx)
    if state.current_bullet_idx >= len(state.bullets):
        state.current_bullet_idx = 0
    return bullet

# ==================== DISPLAY FUNCTIONS ====================
def clear_display():
    oled.fill(0)

def show_display():
    oled.show()

def draw_text(text, x, y):
    oled.text(text, x, y)

def draw_rect(x, y, w, h, color=1):
    oled.rect(x, y, w, h, color)

def draw_fill_rect(x, y, w, h, color=1):
    oled.fill_rect(x, y, w, h, color)

def draw_skull(x, y, size=8):
    draw_fill_rect(x, y, size, size, 1)
    draw_fill_rect(x+2, y+2, size-4, size-4, 0)
    draw_fill_rect(x+2, y+2, 2, 2, 1)
    draw_fill_rect(x+size-4, y+2, 2, 2, 1)

# ==================== ANIMATIONS ====================
def spin_animation(frames=10):
    for frame in range(frames):
        clear_display()
        cx, cy = 64, 32
        for i in range(8):
            angle = (frame * 0.5 + i * 0.8)
            x = int(cx + 25 * (0.7 + 0.3 * (i % 2)) * (1 if i % 3 == 0 else -1))
            y = int(cy + 20 * (1 if i % 2 == 0 else -1))
            oled.pixel(x, y, 1)
        draw_text("LOADING", 40, 55)
        show_display()
        time.sleep(0.04)

def flash_animation(count=2):
    for _ in range(count):
        oled.invert(1)
        show_display()
        time.sleep(0.06)
        oled.invert(0)
        show_display()
        time.sleep(0.06)

def shot_animation(target_demon, is_live):
    clear_display()
    
    if is_live:
        for i in range(3):
            if i % 2 == 0:
                clear_display()
                draw_text("*** BANG! ***", 25, 28)
            else:
                oled.fill(1)
            show_display()
            time.sleep(0.08)
        
        clear_display()
        if target_demon:
            draw_text("DEMON HIT!", 30, 20)
            draw_skull(55, 35, 14)
        else:
            draw_text("YOU ARE HIT!", 20, 20)
            draw_skull(55, 35, 14)
        show_display()
        time.sleep(0.6)
    else:
        draw_text("*click*", 42, 25)
        draw_text("BLANK!", 40, 38)
        show_display()
        time.sleep(0.5)

def death_animation():
    for frame in range(6):
        clear_display()
        draw_text("YOU DIED", 30, 8)
        draw_skull(40 + frame*2, 25, 16)
        for i in range(4):
            drip = (frame + i*2) % 12
            draw_fill_rect(20 + i*25, 0, 2, drip, 1)
        show_display()
        time.sleep(0.1)

# ==================== DIFFICULTY SELECT SCREEN ====================
def difficulty_select_screen():
    difficulties = ["EASY", "HARD", "1-LIFE"]
    
    while state.phase == "difficulty_select":
        clear_display()
        draw_text("SELECT MODE:", 20, 0)
        
        for i, diff in enumerate(difficulties):
            y = 15 + i * 16
            cursor = ">" if i == state.difficulty_selected_index else " "
            draw_text(cursor + diff, 30, y)
        
        draw_text("1:move  2:select", 10, 54)
        show_display()
        
        action = read_button()
        
        if action == 1:
            state.difficulty_selected_index = (state.difficulty_selected_index + 1) % 3
            time.sleep(0.1)
        
        elif action == 2:
            if state.difficulty_selected_index == 0:
                state.difficulty = "EASY"
            elif state.difficulty_selected_index == 1:
                state.difficulty = "HARD"
            else:
                state.difficulty = "ONE_LIFE"
            
            state.phase = "start"
            time.sleep(0.2)
            return

# ==================== SCREENS ====================
def start_screen():
    clear_display()
    draw_text("DEMON", 40, 15)
    draw_text("ROULETTE", 32, 30)
    draw_text("Press button", 20, 48)
    show_display()
    
    while button.value():
        time.sleep(0.01)
    while not button.value():
        time.sleep(0.01)
    time.sleep(0.1)
    
    spin_animation(10)
    flash_animation(2)

def game_over_screen(win):
    if win:
        clear_display()
        draw_text("VICTORY!", 32, 15)
        draw_text("Demon defeated", 18, 30)
        draw_text("Press to continue", 6, 48)
        show_display()
    else:
        death_animation()
        clear_display()
        draw_text("YOU DIED", 32, 15)
        draw_text("Game Over", 30, 30)
        draw_text("Press to continue", 6, 48)
        show_display()
    
    time.sleep(0.5)
    while button.value():
        time.sleep(0.01)
    while not button.value():
        time.sleep(0.01)
    time.sleep(0.3)
    
    state.phase = "difficulty_select"

def draw_game_screen():
    clear_display()
    
    draw_text("YOU", 0, 0)
    for i in range(state.lives_player):
        draw_fill_rect(24 + i*7, 0, 5, 6, 1)
    
    draw_text("DEM", 88, 0)
    for i in range(state.lives_demon):
        draw_fill_rect(112 + i*7, 0, 5, 6, 1)
    
    draw_text("CHAMBER:", 0, 8)
    for i in range(len(state.bullets)):
        x = 56 + i*7
        if i < state.current_bullet_idx:
            draw_rect(x, 7, 5, 7, 1)
        elif i == state.current_bullet_idx:
            draw_fill_rect(x, 7, 5, 7, 1)
        else:
            draw_rect(x, 7, 5, 7, 1)
    
    if state.player_turn:
        draw_text(">> YOUR TURN <<", 12, 18)
    else:
        draw_text(">> DEMON TURN <<", 10, 18)
    
    draw_text(state.difficulty[:7], 95, 18)
    
    if state.player_turn and state.magnify_info is not None:
        bullet_type = "LIVE" if state.magnify_info == 1 else "BLANK"
        draw_text("INFO:" + bullet_type, 2, 28)
    
    if state.player_turn and state.items:
        draw_text("ITEMS:", 0, 36)
        for i, item in enumerate(state.items[:3]):
            icon = ITEM_ICONS.get(item, "?")
            draw_text("[" + icon + "]", 40 + i*26, 36)
    
    if state.player_turn:
        target = "DEMON" if state.target_is_demon else "SELF"
        draw_text("TARGET:" + target, 2, 46)
    
    if state.message:
        draw_text(state.message[:20], 2, 54)
    
    if state.handcuffs_active:
        draw_text("CUFF", 100, 46)
    if state.player_cuffed:
        draw_text("CUFFED", 95, 54)
    
    show_display()

def draw_item_menu():
    clear_display()
    draw_text("SELECT ITEM:", 20, 0)
    
    for i, item in enumerate(state.items):
        y = 12 + i * 10
        cursor = ">" if i == state.selected_item_index else " "
        name = ITEM_NAMES.get(item, "ITEM")
        icon = ITEM_ICONS.get(item, "?")
        draw_text(cursor + "[" + icon + "]" + name[:7], 10, y)
    
    exit_y = 12 + len(state.items) * 10
    cursor = ">" if state.selected_item_index == len(state.items) else " "
    draw_text(cursor + "[EXIT]", 10, exit_y)
    
    draw_text("1:move 2:use 3:exit", 2, 55)
    
    show_display()

# ==================== BUTTON HANDLING ====================
def read_button():
    if button.value():
        return 0
    
    press_time = time.ticks_ms()
    
    while not button.value():
        if time.ticks_diff(time.ticks_ms(), press_time) > 1500:
            while not button.value():
                time.sleep(0.01)
            time.sleep(0.02)
            return 3
        time.sleep(0.01)
    
    release_time = time.ticks_ms()
    
    while time.ticks_diff(time.ticks_ms(), release_time) < 350:
        if not button.value():
            while not button.value():
                time.sleep(0.01)
            time.sleep(0.02)
            return 2
        time.sleep(0.01)
    
    return 1

# ==================== ULTRA ENHANCED DEMON AI ====================
def demon_easy_ai():
    """Easy mode AI - Still challenging"""
    if len(state.bullets) == 0:
        return "shoot_player"
    
    live_count = sum(state.bullets)
    blank_count = len(state.bullets) - live_count
    
    # EASY AI: Smart but beatable
    if state.demon_magnify_info == 1:
        return "shoot_player"  # 100% shoot player if knows it's live
    elif state.demon_magnify_info == 0:
        return "shoot_demon"   # 100% shoot self if knows it's blank
    
    # Consider player's health
    if state.lives_player <= 1 and live_count > 0:
        return "shoot_player" if random.random() < 0.8 else "shoot_demon"
    
    # Consider demon's health
    if state.lives_demon <= 1 and blank_count > 0:
        return "shoot_demon" if random.random() < 0.8 else "shoot_player"
    
    # Probability based decision
    if live_count > blank_count:
        return "shoot_player" if random.random() < 0.75 else "shoot_demon"
    elif blank_count > live_count:
        return "shoot_demon" if random.random() < 0.75 else "shoot_player"
    else:
        return random.choice(["shoot_player", "shoot_demon"])

def demon_hard_ai():
    """Hard mode AI - Very difficult"""
    if len(state.bullets) == 0:
        return "shoot_player"
    
    live_count = sum(state.bullets)
    blank_count = len(state.bullets) - live_count
    
    # HARD AI: Uses magnify info aggressively
    if state.demon_magnify_info == 1:
        # Knows it's live - check if can finish player
        if state.lives_player <= 2:
            return "shoot_player"  # Go for kill
        elif state.saw_active_demon:
            return "shoot_player"  # Double damage with saw
        else:
            return "shoot_player" if random.random() < 0.95 else "shoot_demon"
    elif state.demon_magnify_info == 0:
        # Knows it's blank - free extra turn
        return "shoot_demon" if random.random() < 0.95 else "shoot_player"
    
    # Advanced strategy based on game state
    if state.lives_player <= 1:
        # Player is one shot from death - go for kill if any live rounds
        if live_count > 0:
            return "shoot_player" if random.random() < 0.9 else "shoot_demon"
    
    if state.lives_demon <= 1:
        # Demon is one shot from death - play safe
        if blank_count > 0:
            return "shoot_demon" if random.random() < 0.9 else "shoot_player"
    
    # Count remaining bullets for strategy
    total_bullets = len(state.bullets)
    if total_bullets <= 2:
        # Endgame - be extra careful
        if live_count > 0 and state.lives_player <= 2:
            return "shoot_player"
        elif blank_count > 0 and state.lives_demon <= 1:
            return "shoot_demon"
    
    # Main decision logic
    if live_count >= total_bullets * 0.7:  # 70%+ live rounds
        return "shoot_player" if random.random() < 0.9 else "shoot_demon"
    elif live_count <= total_bullets * 0.3:  # 30% or less live rounds
        return "shoot_demon" if random.random() < 0.85 else "shoot_player"
    elif live_count > blank_count:
        return "shoot_player" if random.random() < 0.85 else "shoot_demon"
    elif blank_count > live_count:
        return "shoot_demon" if random.random() < 0.8 else "shoot_player"
    else:
        return "shoot_player" if random.random() < 0.7 else "shoot_demon"

def demon_one_life_ai():
    """One-Life mode AI - Nearly unbeatable"""
    if len(state.bullets) == 0:
        return "shoot_player"
    
    live_count = sum(state.bullets)
    blank_count = len(state.bullets) - live_count
    total_bullets = len(state.bullets)
    
    # ONE-LIFE AI: Perfect information usage
    if state.demon_magnify_info == 1:
        # Knows it's live - calculate optimal target
        if state.lives_player <= 1:
            return "shoot_player"  # Guaranteed kill
        elif state.saw_active_demon and state.lives_player <= 2:
            return "shoot_player"  # Saw double damage kill
        elif live_count > blank_count:
            return "shoot_player" if random.random() < 0.98 else "shoot_demon"
        else:
            return "shoot_player" if random.random() < 0.95 else "shoot_demon"
    elif state.demon_magnify_info == 0:
        # Knows it's blank - guaranteed extra turn
        if state.lives_demon <= 1 and blank_count == 1:
            return "shoot_demon"  # Safe way to get extra turn
        return "shoot_demon" if random.random() < 0.98 else "shoot_player"
    
    # Perfect play decision tree
    if state.lives_player <= 1:
        # Can kill player - go for it if any chance
        if live_count > 0:
            return "shoot_player" if random.random() < 0.95 else "shoot_demon"
    
    if state.lives_demon <= 1:
        # Demon nearly dead - maximum survival instinct
        if blank_count > 0:
            return "shoot_demon"  # Always play safe
        elif live_count > blank_count and state.lives_player <= 1:
            return "shoot_player"  # Last resort offense
    
    # Analyze player behavior patterns
    if state.player_used_magnify_recently and live_count > blank_count:
        # Player just checked bullet and is acting confident - it might be live
        return "shoot_player" if random.random() < 0.9 else "shoot_demon"
    
    # Endgame perfection
    if total_bullets <= 2:
        if live_count == 2:
            return "shoot_player"  # Both live - must shoot player
        elif live_count == 1 and blank_count == 1:
            if state.lives_demon <= 1:
                return "shoot_demon" if random.random() < 0.7 else "shoot_player"
            else:
                return "shoot_player"  # Risk it for damage
        elif blank_count == 2:
            return "shoot_demon"  # Both blank - free extra turns
    
    # Statistical perfection
    live_ratio = live_count / total_bullets if total_bullets > 0 else 0
    
    if live_ratio >= 0.8:  # 80%+ live
        return "shoot_player" if random.random() < 0.95 else "shoot_demon"
    elif live_ratio >= 0.6:  # 60-80% live
        if state.lives_player <= 1:
            return "shoot_player" if random.random() < 0.9 else "shoot_demon"
        elif state.saw_active_demon:
            return "shoot_player" if random.random() < 0.9 else "shoot_demon"
        else:
            return "shoot_player" if random.random() < 0.85 else "shoot_demon"
    elif live_ratio <= 0.2:  # 20% or less live
        return "shoot_demon" if random.random() < 0.95 else "shoot_player"
    elif live_ratio <= 0.4:  # 20-40% live
        if state.lives_demon <= 1:
            return "shoot_demon"  # Play safe when low health
        else:
            return "shoot_demon" if random.random() < 0.85 else "shoot_player"
    elif live_count > blank_count:
        return "shoot_player" if random.random() < 0.8 else "shoot_demon"
    elif blank_count > live_count:
        return "shoot_demon" if random.random() < 0.75 else "shoot_player"
    else:
        return "shoot_player" if random.random() < 0.65 else "shoot_demon"

def use_item(item, is_player=True):
    if item == ITEM_MAGNIFY:
        bullet = current_bullet()
        if bullet is not None:
            if is_player:
                state.magnify_info = bullet
                state.message = "Bullet checked!"
                state.player_used_magnify_recently = True
            else:
                state.demon_magnify_info = bullet
                state.message = "Demon checks..."
            return True
        else:
            state.message = "No bullets!"
            return False
    
    elif item == ITEM_CIGARETTE:
        if is_player:
            max_lives = 2 if state.difficulty == "ONE_LIFE" else 3
            if state.lives_player < max_lives:
                state.lives_player += 1
                state.message = "Healed +1 life!"
                return True
            else:
                state.message = "Already full HP"
                return False
        else:
            max_lives = 2 if state.difficulty == "ONE_LIFE" else 3
            if state.lives_demon < max_lives:
                state.lives_demon += 1
                state.message = "Demon heals..."
                return True
            return False
    
    elif item == ITEM_BEER:
        if len(state.bullets) > 0:
            state.bullets.pop(state.current_bullet_idx)
            if state.current_bullet_idx >= len(state.bullets):
                state.current_bullet_idx = 0
            state.message = "Bullet ejected!" if is_player else "Demon ejects..."
            return True
        else:
            state.message = "No bullets!"
            return False
    
    elif item == ITEM_HANDCUFFS:
        if is_player:
            state.handcuffs_active = True
            state.message = "Demon cuffed!"
        else:
            state.player_cuffed = True
            state.message = "You are cuffed!"
        return True
    
    elif item == ITEM_SAW:
        state.message = "Saw activated!" if is_player else "Demon uses saw..."
        if not is_player:
            state.saw_active_demon = True
        return True
    
    return False

def check_game_over():
    if state.lives_player <= 0:
        state.game_over = True
        game_over_screen(False)
        return True
    elif state.lives_demon <= 0:
        state.game_over = True
        game_over_screen(True)
        return True
    
    if len(state.bullets) == 0:
        new_round()
        return True
    
    return False

def demon_turn():
    """Ultra enhanced demon turn"""
    state.player_turn = False
    state.magnify_info = None
    state.player_used_magnify_recently = False
    
    state.message = "Demon thinking..."
    draw_game_screen()
    time.sleep(0.8)
    
    if state.handcuffs_active:
        state.handcuffs_active = False
        state.message = "Demon is cuffed!"
        draw_game_screen()
        time.sleep(1.0)
        state.player_turn = True
        return False
    
    if state.player_cuffed:
        state.player_cuffed = False
        state.message = "You are cuffed!"
        draw_game_screen()
        time.sleep(0.8)
        state.player_turn = False
        return demon_turn()
    
    # Reset saw status
    state.saw_active_demon = False
    
    # Item usage strategy (ultra enhanced)
    if state.demon_items:
        items_used = []
        for i, item in enumerate(state.demon_items):
            if item == ITEM_MAGNIFY and state.demon_magnify_info is None:
                state.message = "Demon checks bullet"
                draw_game_screen()
                time.sleep(0.8)
                items_used.append(i)
                use_item(item, False)
                break  # Use magnify first if no info
                
        # Remove used items
        for i in sorted(items_used, reverse=True):
            if i < len(state.demon_items):
                state.demon_items.pop(i)
    
    # Strategic item usage
    if state.demon_items:
        for i, item in enumerate(state.demon_items):
            if item == ITEM_BEER and len(state.bullets) > 0:
                live_count = sum(state.bullets)
                total = len(state.bullets)
                
                # Use beer if too many live rounds
                threshold = total // 4 if state.difficulty == "ONE_LIFE" else total // 3 if state.difficulty == "HARD" else total // 2
                
                if live_count > threshold:
                    state.message = "Demon uses beer"
                    draw_game_screen()
                    time.sleep(0.8)
                    state.demon_items.pop(i)
                    use_item(item, False)
                    break
                    
            elif item == ITEM_CIGARETTE:
                max_lives = 2 if state.difficulty == "ONE_LIFE" else 3
                if state.lives_demon < max_lives:
                    state.message = "Demon heals"
                    draw_game_screen()
                    time.sleep(0.8)
                    state.demon_items.pop(i)
                    use_item(item, False)
                    break
                
            elif item == ITEM_SAW and not state.saw_active_demon:
                live_count = sum(state.bullets)
                total = len(state.bullets)
                threshold = total // 5 if state.difficulty == "ONE_LIFE" else total // 4 if state.difficulty == "HARD" else total // 3
                
                if live_count >= threshold:
                    state.message = "Demon uses saw"
                    draw_game_screen()
                    time.sleep(0.8)
                    state.demon_items.pop(i)
                    use_item(item, False)
                    break
                    
            elif item == ITEM_HANDCUFFS:
                if state.difficulty == "ONE_LIFE":
                    # Almost always use handcuffs in one-life mode
                    if random.random() < 0.9:
                        state.message = "Demon cuffs you!"
                        draw_game_screen()
                        time.sleep(0.8)
                        state.demon_items.pop(i)
                        use_item(item, False)
                        break
                elif state.difficulty == "HARD":
                    if random.random() < 0.7:
                        state.message = "Demon cuffs you!"
                        draw_game_screen()
                        time.sleep(0.8)
                        state.demon_items.pop(i)
                        use_item(item, False)
                        break
                else:
                    if random.random() < 0.5:
                        state.message = "Demon cuffs you!"
                        draw_game_screen()
                        time.sleep(0.8)
                        state.demon_items.pop(i)
                        use_item(item, False)
                        break
    
    # Decision making based on difficulty
    if state.difficulty == "EASY":
        action = demon_easy_ai()
    elif state.difficulty == "HARD":
        action = demon_hard_ai()
    else:  # ONE_LIFE
        action = demon_one_life_ai()
    
    state.message = "Demon fires!"
    draw_game_screen()
    time.sleep(0.5)
    
    bullet = fire_bullet()
    if bullet == -1:
        new_round()
        return False
    
    is_live = (bullet == 1)
    target_demon = (action == "shoot_demon")
    
    shot_animation(target_demon, is_live)
    
    if is_live:
        damage = 2 if state.saw_active_demon else 1
        if target_demon:
            state.lives_demon = max(0, state.lives_demon - damage)
            state.message = "Demon shot itself!"
        else:
            state.lives_player = max(0, state.lives_player - damage)
            state.message = "You got shot!"
        
        if check_game_over():
            return True
    else:
        state.message = "Blank - safe!"
        if target_demon:
            state.message = "Demon extra turn!"
            draw_game_screen()
            time.sleep(0.5)
            
            if len(state.bullets) == 0:
                new_round()
                return False
            
            state.player_turn = False
            return demon_turn()
    
    state.player_turn = True
    
    if len(state.bullets) == 0:
        new_round()
    
    return False

def player_shoot():
    state.magnify_info = None
    state.player_used_magnify_recently = False
    
    if len(state.bullets) == 0:
        state.message = "No bullets!"
        draw_game_screen()
        time.sleep(0.5)
        new_round()
        return False
    
    state.message = "Firing..."
    draw_game_screen()
    time.sleep(0.4)
    
    bullet = fire_bullet()
    if bullet == -1:
        state.message = "No bullets!"
        draw_game_screen()
        time.sleep(0.5)
        new_round()
        return False
    
    is_live = (bullet == 1)
    target_demon = state.target_is_demon
    
    shot_animation(target_demon, is_live)
    
    if is_live:
        double_damage = False
        if ITEM_SAW in state.items:
            state.items.remove(ITEM_SAW)
            double_damage = True
            state.message = "SAW - Double damage!"
        
        damage = 2 if double_damage else 1
        
        if target_demon:
            state.lives_demon = max(0, state.lives_demon - damage)
            state.message = "Demon hit!"
        else:
            state.lives_player = max(0, state.lives_player - damage)
            state.message = "Self hit!"
        
        if check_game_over():
            return True
    else:
        state.message = "Blank!"
        if not target_demon:
            state.message = "Blank! Extra turn!"
            state.player_turn = True
            
            if len(state.bullets) == 0:
                draw_game_screen()
                time.sleep(0.5)
                new_round()
            return False
    
    state.player_turn = False
    
    if len(state.bullets) == 0:
        new_round()
        return False
    
    return demon_turn()

def new_round():
    state.round += 1
    state.bullets = generate_bullets()
    state.current_bullet_idx = 0
    state.player_turn = True
    state.target_is_demon = True
    state.message = f"Round {state.round}"
    state.magnify_info = None
    state.demon_magnify_info = None
    state.handcuffs_active = False
    state.player_cuffed = False
    state.saw_active_demon = False
    state.player_used_magnify_recently = False
    
    # Items distribution
    if state.difficulty == "EASY":
        state.items = [random_item() for _ in range(min(2, state.round))]
        state.demon_items = [random_item() for _ in range(min(1, state.round))]
    elif state.difficulty == "HARD":
        state.items = [random_item() for _ in range(min(1, state.round))]
        state.demon_items = [random_item() for _ in range(min(2, state.round))]
    else:  # ONE_LIFE
        state.items = [random_item() for _ in range(min(1, max(1, state.round - 1)))]
        state.demon_items = [random_item() for _ in range(min(2, state.round))]
    
    clear_display()
    draw_text(f"ROUND {state.round}", 32, 20)
    draw_text(f"Bullets: {len(state.bullets)}", 24, 35)
    show_display()
    time.sleep(1.5)

def handle_item_menu():
    if not state.items:
        state.item_menu_active = False
        return False
    
    draw_item_menu()
    time.sleep(0.15)
    
    while state.item_menu_active:
        action = read_button()
        
        if action == 1:
            state.selected_item_index = (state.selected_item_index + 1) % (len(state.items) + 1)
            draw_item_menu()
            time.sleep(0.08)
        
        elif action == 2:
            if state.selected_item_index == len(state.items):
                state.item_menu_active = False
                state.message = ""
                return False
            
            selected_item = state.items.pop(state.selected_item_index)
            state.selected_item_index = 0
            state.item_menu_active = False
            
            if use_item(selected_item, True):
                return True
            else:
                state.items.append(selected_item)
                return False
        
        elif action == 3:
            state.item_menu_active = False
            state.message = ""
            return False
        
        time.sleep(0.03)

def handle_input():
    if state.game_over:
        return
    
    if state.item_menu_active:
        handle_item_menu()
        return
    
    action = read_button()
    
    if action == 1:
        if state.items:
            state.item_menu_active = True
            state.selected_item_index = 0
            handle_item_menu()
        else:
            state.target_is_demon = not state.target_is_demon
            target = "DEMON" if state.target_is_demon else "SELF"
            state.message = f"Target: {target}"
    
    elif action == 2:
        player_shoot()

def main():
    print("Demon Roulette starting...")
    
    while True:
        try:
            if state.phase == "difficulty_select":
                difficulty_select_screen()
                
            elif state.phase == "start":
                start_screen()
                state.reset()
                
                if state.difficulty == "ONE_LIFE":
                    state.lives_player = 2
                    state.lives_demon = 2
                else:
                    state.lives_player = 3
                    state.lives_demon = 3
                
                state.bullets = generate_bullets()
                state.items = [random_item()]
                state.message = f"Mode: {state.difficulty}"
                state.phase = "playing"
                draw_game_screen()
                time.sleep(1)
            
            elif state.phase == "playing":
                if not state.game_over:
                    if state.player_turn:
                        draw_game_screen()
                        handle_input()
                    else:
                        demon_turn()
                        draw_game_screen()
            
            time.sleep(0.03)
            
        except Exception as e:
            print(f"Error: {e}")
            time.sleep(0.5)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        clear_display()
        show_display()
        print("Game stopped by user")