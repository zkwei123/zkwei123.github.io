from machine import Pin, I2C
import ssd1306
import framebuf
import time
import random
import json

# 初始化OLED
i2c = I2C(0, scl=Pin(9), sda=Pin(8), freq=400000)
oled = ssd1306.SSD1306_I2C(128, 64, i2c)

# 初始化按钮
button = Pin(21, Pin.IN, Pin.PULL_UP)

# ========== 游戏状态 ==========
game_started = False
game_over_flag = False
game_win_flag = False
distance = 0
high_score = 0

# 难度选择
difficulty = 0
selecting_difficulty = True
button_press_count = 0
last_button_time = 0

# 恐龙参数
dino_y_ground = 48
dino_x = 20
dino_y = dino_y_ground
dino_jump_velocity = -7.0
dino_gravity = 0.85
is_jumping = False
jump_velocity = 0.0

# 障碍物
obstacles = []
obstacle_speed = 4

# 翼龙参数
pterosaur_y_flying = 35

# 计数器
frame_counter = 0
distance_counter = 0

# 昼夜循环
day_night_cycle = 0
cycle_distance = 300

# ========== 图形定义 ==========
# 恐龙站姿
dino_fb = framebuf.FrameBuffer(bytearray(32), 16, 16, framebuf.MONO_HLSB)
dino_fb.fill(0)
dino_fb.rect(0, 12, 4, 4, 1)
dino_fb.rect(4, 8, 4, 8, 1)
dino_fb.rect(8, 4, 4, 4, 1)
dino_fb.pixel(12, 6, 1)
dino_fb.line(3, 10, 0, 8, 1)

# 恐龙跳跃
dino_jump_fb = framebuf.FrameBuffer(bytearray(32), 16, 16, framebuf.MONO_HLSB)
dino_jump_fb.fill(0)
dino_jump_fb.rect(0, 12, 4, 4, 1)
dino_jump_fb.rect(4, 8, 4, 8, 1)
dino_jump_fb.rect(8, 4, 4, 4, 1)
dino_jump_fb.pixel(12, 6, 0)
dino_jump_fb.pixel(11, 5, 1)
dino_jump_fb.line(3, 10, 0, 8, 1)

# 仙人掌
cactus1_fb = framebuf.FrameBuffer(bytearray(16), 8, 16, framebuf.MONO_HLSB)
cactus1_fb.fill(0)
cactus1_fb.rect(2, 0, 4, 16, 1)

cactus2_fb = framebuf.FrameBuffer(bytearray(32), 16, 16, framebuf.MONO_HLSB)
cactus2_fb.fill(0)
cactus2_fb.rect(2, 0, 4, 16, 1)
cactus2_fb.rect(10, 4, 4, 12, 1)

cactus3_fb = framebuf.FrameBuffer(bytearray(48), 24, 16, framebuf.MONO_HLSB)
cactus3_fb.fill(0)
cactus3_fb.rect(2, 0, 4, 16, 1)
cactus3_fb.rect(10, 4, 4, 12, 1)
cactus3_fb.rect(18, 2, 4, 14, 1)

# 翼龙
pterosaur_fb1 = framebuf.FrameBuffer(bytearray(16), 16, 8, framebuf.MONO_HLSB)
pterosaur_fb1.fill(0)
pterosaur_fb1.ellipse(8, 4, 6, 3, 1)
pterosaur_fb1.line(2, 3, 0, 0, 1)
pterosaur_fb1.line(2, 5, 0, 8, 1)
pterosaur_fb1.line(14, 3, 16, 0, 1)
pterosaur_fb1.line(14, 5, 16, 8, 1)
pterosaur_fb1.pixel(6, 4, 1)

pterosaur_fb2 = framebuf.FrameBuffer(bytearray(16), 16, 8, framebuf.MONO_HLSB)
pterosaur_fb2.fill(0)
pterosaur_fb2.ellipse(8, 4, 6, 3, 1)
pterosaur_fb2.line(4, 3, 1, 2, 1)
pterosaur_fb2.line(4, 5, 1, 6, 1)
pterosaur_fb2.line(12, 3, 15, 2, 1)
pterosaur_fb2.line(12, 5, 15, 6, 1)
pterosaur_fb2.pixel(6, 4, 1)

pterosaur_frame = 0
pterosaur_animation_counter = 0

# ========== 胜利动画函数 ==========
def create_dino_fb():
    """创建恐龙站姿的FrameBuffer"""
    dino_fb = framebuf.FrameBuffer(bytearray(32), 16, 16, framebuf.MONO_HLSB)
    dino_fb.fill(0)
    dino_fb.rect(0, 12, 4, 4, 1)
    dino_fb.rect(4, 8, 4, 8, 1)
    dino_fb.rect(8, 4, 4, 4, 1)
    dino_fb.pixel(12, 6, 1)
    dino_fb.line(3, 10, 0, 8, 1)
    return dino_fb

def draw_dino(x, y, fb, flip=False):
    """绘制恐龙"""
    if flip:
        oled.blit(fb, x, y, -1)
    else:
        oled.blit(fb, x, y)

def draw_flower(x, y):
    """在恐龙手上画一朵花"""
    oled.pixel(x+14, y+10, 1)
    oled.pixel(x+13, y+9, 1)
    oled.pixel(x+15, y+9, 1)
    oled.pixel(x+13, y+11, 1)
    oled.pixel(x+15, y+11, 1)
    oled.pixel(x+14, y+10, 1)

def draw_bow(x, y):
    """画蝴蝶结"""
    oled.pixel(x+5, y-1, 1)
    oled.pixel(x+6, y-2, 1)
    oled.pixel(x+7, y-2, 1)
    oled.pixel(x+8, y-2, 1)
    oled.pixel(x+9, y-1, 1)
    oled.pixel(x+7, y-3, 1)

def draw_cactus(x, y):
    """画仙人掌"""
    oled.fill_rect(x+1, y, 6, 12, 1)
    oled.fill_rect(x, y+2, 2, 4, 1)
    oled.fill_rect(x+6, y+4, 2, 4, 1)
    oled.fill_rect(x+2, y-2, 4, 2, 1)
    oled.pixel(x, y+5, 1)
    oled.pixel(x+7, y+7, 1)

def draw_tear(x, y):
    """画一滴泪"""
    oled.pixel(x, y, 1)
    oled.pixel(x+1, y+1, 1)
    oled.pixel(x, y+2, 1)
    oled.pixel(x-1, y+1, 1)

def draw_heart(x, y):
    """画爱心"""
    oled.pixel(x, y, 1)
    oled.pixel(x+2, y, 1)
    oled.pixel(x+1, y+1, 1)
    oled.pixel(x, y+2, 1)
    oled.pixel(x+2, y+2, 1)
    oled.pixel(x+1, y+3, 1)

def scene1_intro():
    """场景1: 拿花恐龙看着戴蝴蝶结恐龙"""
    for frame in range(40):
        oled.fill(0)
        draw_dino(10, 20, create_dino_fb())
        draw_flower(10, 20)
        draw_dino(75, 20, create_dino_fb())
        draw_bow(75, 20)
        draw_dino(55, 20, create_dino_fb(), flip=False)
        draw_heart(67, 10)
        oled.line(28, 25, 52, 20, 1)
        oled.show()
        time.sleep(0.08)

def scene2_cry():
    """场景2: 流泪"""
    for frame in range(30):
        oled.fill(0)
        draw_dino(30, 15, create_dino_fb())
        draw_flower(30, 15)
        tear_y = 30 + frame % 12
        draw_tear(50, tear_y)
        oled.line(50, 30, 50, tear_y, 1)
        oled.pixel(40, 22, 1)
        oled.pixel(46, 22, 1)
        oled.show()
        time.sleep(0.1)

def scene3_run():
    """场景3: 开始跑步"""
    for x in range(-20, 130, 3):
        oled.fill(0)
        if x % 6 < 3:
            draw_dino(x, 25, create_dino_fb())
        else:
            draw_dino(x, 23, create_dino_fb())
        for i in range(4):
            oled.line(x-10-i*6, 30+i*4, x-4-i*6, 30+i*4, 1)
        oled.text("RUN!!", 5, 55, 1)
        oled.show()
        time.sleep(0.04)

def scene4_crash():
    """场景4: 撞到仙人掌"""
    for x in range(110, 70, -2):
        oled.fill(0)
        draw_dino(x, 25, create_dino_fb())
        draw_cactus(120, 28)
        oled.show()
        time.sleep(0.03)
    
    for shake in range(8):
        oled.fill(0)
        draw_dino(70 + (shake%2)*2, 25 + (shake%3)*1, create_dino_fb())
        draw_cactus(120, 28)
        oled.text("X_X", 55, 10, 1)
        oled.show()
        time.sleep(0.1)
    
    for frame in range(12):
        oled.fill(0)
        draw_dino(70 + frame//3, 28 + frame//2, create_dino_fb())
        draw_cactus(120, 28)
        oled.pixel(55 - frame, 18 - frame, 1)
        oled.pixel(53 - frame, 20 - frame, 1)
        oled.pixel(57 - frame, 20 - frame, 1)
        oled.text("RIP", 10, 50, 1)
        oled.show()
        time.sleep(0.12)

def scene5_victory():
    """场景5: 显示胜利成就"""
    for pulse in range(8):
        oled.fill(0)
        offset = pulse % 2
        oled.text("YOU WIN!", 20 + offset, 10 + offset, 1)
        oled.text("YOU WIN!", 22 + offset, 12 + offset, 1)
        oled.text("Achievement:", 15, 30, 1)
        oled.text("9999m Chase", 20, 42, 1)
        for i in range(6):
            if (pulse + i) % 2 == 0:
                oled.pixel(10 + i*20, 55, 1)
                oled.pixel(15 + i*20, 58, 1)
        oled.show()
        time.sleep(0.3)

def play_victory_animation():
    """播放完整胜利动画"""
    scene1_intro()
    scene2_cry()
    scene3_run()
    scene4_crash()
    scene5_victory()
    print("🏆 故事结束 - 成就解锁: 9999m Chase!")

# ========== 游戏核心函数 ==========

def load_high_score():
    global high_score
    try:
        with open('dino_data.json', 'r') as f:
            data = json.load(f)
            high_score = data.get('high_score', 0)
    except:
        high_score = 0

def save_high_score():
    global high_score, distance
    if distance > high_score:
        high_score = distance
        try:
            with open('dino_data.json', 'w') as f:
                json.dump({'high_score': high_score}, f)
        except:
            pass

def show_difficulty_menu():
    oled.fill(0)
    oled.text("SELECT MODE", 24, 5)
    oled.text("SINGLE: SWITCH", 12, 20)
    oled.text("DOUBLE: CONFIRM", 12, 30)
    
    if difficulty == 1:
        oled.text("> EASY <", 44, 45)
    elif difficulty == 2:
        oled.text("> HARD <", 44, 45)
    elif difficulty == 3:
        oled.text("> SPEEDRUN <", 36, 45)
    else:
        oled.text("> NONE <", 44, 45)
    
    if difficulty == 1:
        oled.text("Normal", 48, 55)
    elif difficulty == 2:
        oled.text("Hard + Night", 40, 55)
    elif difficulty == 3:
        oled.text("Pterosaur Rush!", 32, 55)
    
    oled.show()

def show_start_screen():
    oled.fill(0)
    oled.text("DINO GAME", 32, 10)
    oled.text("Press to START", 20, 30)
    
    if difficulty == 1:
        oled.text("EASY", 52, 45)
    elif difficulty == 2:
        oled.text("HARD", 52, 45)
    elif difficulty == 3:
        oled.text("SPEEDRUN", 44, 45)
    
    oled.text("9999m to WIN", 28, 55)
    oled.show()

def show_game_over():
    global game_over_flag
    save_high_score()
    oled.fill(0)
    oled.text("GAME OVER", 24, 10)
    oled.text(str(distance) + "m", 48, 25)
    oled.text("BEST:" + str(high_score) + "m", 28, 35)
    oled.text("Press to retry", 20, 50)
    oled.show()
    game_over_flag = True

def show_win_screen():
    global game_win_flag
    save_high_score()
    oled.fill(0)
    oled.text("YOU WIN!", 32, 10)
    oled.text("9999m", 48, 25)
    oled.text("BEST:" + str(high_score) + "m", 28, 35)
    oled.text("Press to retry", 20, 50)
    oled.show()
    game_win_flag = True

def draw_ground():
    global ground_offset
    ground_offset = (ground_offset + 1) & 15
    oled.hline(0, dino_y_ground + 8, 128, 1)
    if ground_offset < 8:
        oled.hline(ground_offset, dino_y_ground + 8, 8, 0)

def update_dino():
    global dino_y, is_jumping, jump_velocity
    if is_jumping:
        dino_y += jump_velocity
        jump_velocity += dino_gravity
        if dino_y >= dino_y_ground:
            dino_y = dino_y_ground
            is_jumping = False
            jump_velocity = 0.0

def check_collision():
    dino_left = dino_x
    dino_right = dino_x + 16
    dino_top = int(dino_y)
    dino_bottom = int(dino_y) + 16
    
    for obs in obstacles:
        if (dino_right > obs['x'] and dino_left < obs['x'] + obs['width'] and
            dino_bottom > obs['y'] and dino_top < obs['y'] + obs['height']):
            return True
    return False

def jump():
    global is_jumping, jump_velocity
    if not is_jumping and game_started and not game_over_flag and not game_win_flag:
        is_jumping = True
        jump_velocity = dino_jump_velocity

def generate_obstacle():
    if obstacles:
        return
    
    if difficulty == 3:
        if random.randint(0, 4) <= 3:
            obstacle = {
                'type': 'pterosaur',
                'x': 128,
                'width': 16,
                'height': 8,
                'y': pterosaur_y_flying,
                'speed_boost': 1.5
            }
        else:
            cactus_count = random.randint(1, 2)
            if cactus_count == 1:
                obstacle = {
                    'type': 'cactus',
                    'x': 128,
                    'width': 8,
                    'height': 16,
                    'y': dino_y_ground + 8,
                    'cactus_count': 1
                }
            else:
                obstacle = {
                    'type': 'cactus',
                    'x': 128,
                    'width': 16,
                    'height': 16,
                    'y': dino_y_ground + 8,
                    'cactus_count': 2
                }
        obstacles.append(obstacle)
    else:
        rand_type = random.randint(0, 3)
        if rand_type <= 2:
            cactus_count = random.randint(1, 3)
            if cactus_count == 1:
                obstacle = {
                    'type': 'cactus',
                    'x': 128,
                    'width': 8,
                    'height': 16,
                    'y': dino_y_ground + 8,
                    'cactus_count': 1
                }
            elif cactus_count == 2:
                obstacle = {
                    'type': 'cactus',
                    'x': 128,
                    'width': 16,
                    'height': 16,
                    'y': dino_y_ground + 8,
                    'cactus_count': 2
                }
            else:
                obstacle = {
                    'type': 'cactus',
                    'x': 128,
                    'width': 24,
                    'height': 16,
                    'y': dino_y_ground + 8,
                    'cactus_count': 3
                }
        else:
            obstacle = {
                'type': 'pterosaur',
                'x': 128,
                'width': 16,
                'height': 8,
                'y': pterosaur_y_flying
            }
        obstacles.append(obstacle)

def move_obstacles():
    for obs in obstacles[:]:
        if obs.get('speed_boost', 0):
            obs['x'] -= obstacle_speed * 2.0
        elif difficulty == 3 and obs['type'] == 'pterosaur':
            obs['x'] -= obstacle_speed * 1.8
        elif obs['type'] == 'pterosaur':
            if difficulty == 1:
                obs['x'] -= obstacle_speed * 0.8
            else:
                obs['x'] -= obstacle_speed * 1.3
        else:
            obs['x'] -= obstacle_speed
        
        if obs['x'] + obs['width'] < 0:
            obstacles.remove(obs)

def update_distance():
    global distance_counter, distance, game_started, game_win_flag
    
    distance_counter += 1
    # 距离增加更快（每3帧增加1米，而不是6帧）
    if distance_counter >= 3:  # 原来是6，改为3
        distance_counter = 0
        distance += 1
        if distance >= 9999 and not game_win_flag:
            game_started = False
            show_win_screen()
            # 播放胜利动画
            play_victory_animation()

def update_day_night_cycle():
    global day_night_cycle
    if difficulty == 2:
        cycle_stage = (distance // cycle_distance) % 2
        day_night_cycle = 1 if cycle_stage == 1 else 0
    else:
        day_night_cycle = 0

def draw_sky_effects():
    if day_night_cycle == 1:
        for i in range(10):
            oled.pixel((i * 37 + distance) & 127, (i * 23) & 63, 1)
        oled.ellipse(110, 5, 4, 4, 1)
        oled.pixel(108, 4, 0)
        oled.text("N", 0, 0)
    else:
        if difficulty != 3:
            oled.ellipse(115, 5, 4, 4, 1)
        oled.text("D", 0, 0)

def display_distance():
    oled.fill_rect(85, 0, 43, 16, 0)
    if distance >= 9999:
        oled.text("9999m", 95, 0)
    else:
        oled.text(str(distance) + "m", 100, 0)
    oled.text(str(high_score), 85, 8)

def update_animation():
    global pterosaur_animation_counter, pterosaur_frame
    
    has_pterosaur = False
    for obs in obstacles:
        if obs['type'] == 'pterosaur':
            has_pterosaur = True
            break
    
    if has_pterosaur:
        pterosaur_animation_counter += 1
        if pterosaur_animation_counter >= 8:
            pterosaur_animation_counter = 0
            pterosaur_frame = 1 - pterosaur_frame
    else:
        pterosaur_frame = 0

def reset_game():
    global game_started, game_over_flag, game_win_flag, distance, obstacles
    global dino_y, is_jumping, jump_velocity, obstacle_speed, frame_counter
    global distance_counter, day_night_cycle
    
    game_started = True
    game_over_flag = False
    game_win_flag = False
    distance = 0
    obstacles.clear()
    dino_y = dino_y_ground
    is_jumping = False
    jump_velocity = 0.0
    
    if difficulty == 1:
        obstacle_speed = 4
    elif difficulty == 2:
        obstacle_speed = 6
    else:
        obstacle_speed = 7
    
    frame_counter = 0
    distance_counter = 0
    day_night_cycle = 0
    
    oled.fill(0)
    oled.show()

def button_handler(pin):
    global selecting_difficulty, difficulty, game_started, game_over_flag
    global game_win_flag, button_press_count, last_button_time
    
    time.sleep_ms(20)
    if pin.value() == 0:
        current_time = time.ticks_ms()
        
        if selecting_difficulty:
            if current_time - last_button_time < 300:
                if difficulty in [1, 2, 3]:
                    selecting_difficulty = False
                    show_start_screen()
                    button_press_count = 0
                    last_button_time = 0
            else:
                if difficulty == 0:
                    difficulty = 1
                elif difficulty == 1:
                    difficulty = 2
                elif difficulty == 2:
                    difficulty = 3
                elif difficulty == 3:
                    difficulty = 1
                show_difficulty_menu()
                button_press_count = 1
                last_button_time = current_time
        else:
            if not game_started and not game_over_flag and not game_win_flag:
                reset_game()
            elif game_over_flag or game_win_flag:
                reset_game()
            else:
                jump()

# ========== 主程序 ==========

# 加载高分
load_high_score()

# 显示难度菜单
selecting_difficulty = True
show_difficulty_menu()

# 设置按钮中断
button.irq(trigger=Pin.IRQ_FALLING, handler=button_handler)

# 主循环
while True:
    if game_started and not game_over_flag and not game_win_flag:
        update_distance()
        update_day_night_cycle()
        update_dino()
        
        frame_counter += 1
        if difficulty == 3:
            gen_interval = random.randint(20, 50)
        elif difficulty == 1:
            gen_interval = random.randint(60, 120)
        else:
            gen_interval = random.randint(40, 80)
        
        if not obstacles and frame_counter > gen_interval:
            generate_obstacle()
            frame_counter = 0
        
        move_obstacles()
        
        if difficulty == 1:
            obstacle_speed = min(4 + distance // 200, 8)
        elif difficulty == 2:
            obstacle_speed = min(6 + distance // 150, 12)
        else:
            obstacle_speed = min(7 + distance // 100, 15)
        
        update_animation()
        
        if check_collision():
            game_started = False
            show_game_over()
            continue
        
        # 渲染
        oled.fill(0)
        draw_sky_effects()
        draw_ground()
        
        if is_jumping:
            oled.blit(dino_jump_fb, dino_x, int(dino_y))
        else:
            oled.blit(dino_fb, dino_x, int(dino_y))
        
        for obs in obstacles:
            if obs['type'] == 'cactus':
                if obs['cactus_count'] == 1:
                    oled.blit(cactus1_fb, int(obs['x']), obs['y'])
                elif obs['cactus_count'] == 2:
                    oled.blit(cactus2_fb, int(obs['x']), obs['y'])
                else:
                    oled.blit(cactus3_fb, int(obs['x']), obs['y'])
            else:
                oled.blit(pterosaur_fb1 if pterosaur_frame else pterosaur_fb2, 
                         int(obs['x']), obs['y'])
        
        display_distance()
        oled.show()
        
        time.sleep_ms(12)
    else:
        time.sleep_ms(50)