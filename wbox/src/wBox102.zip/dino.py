from machine import Pin, I2C
from ssd1306 import SSD1306_I2C
import framebuf
import random
import time
import json

# 初始化OLED（降低频率减少卡顿）
i2c = I2C(0, scl=Pin(9), sda=Pin(8), freq=400000)
oled = SSD1306_I2C(128, 64, i2c)

# 初始化按钮
button = Pin(21, Pin.IN, Pin.PULL_UP)

# 游戏状态
game_started = False
game_over_flag = False
game_win_flag = False
distance = 0
high_score = 0

# 难度选择
difficulty = 0  # 0=未选择, 1=EASY, 2=HARD, 3=SPEEDRUN
selecting_difficulty = True
button_press_count = 0
last_button_time = 0

# 恐龙参数
dino_y_ground = 48
dino_x = 20
dino_y = dino_y_ground
dino_jump_velocity = -7.0  # 稍微增加跳跃力
dino_gravity = 0.85
is_jumping = False
jump_velocity = 0.0

# 障碍物
obstacles = []
obstacle_speed = 4

# 翼龙参数
pterosaur_y_flying = 35
pterosaur_speed_multiplier = 1.0

# 地面滚动
ground_offset = 0

# 计数器（优化：减少变量）
frame_counter = 0
distance_counter = 0

# 昼夜循环
day_night_cycle = 0
cycle_distance = 300

# ========== 简化的图形（减少内存占用）==========
# 恐龙站姿
dino_fb = framebuf.FrameBuffer(bytearray(32), 16, 16, framebuf.MONO_HLSB)
dino_fb.fill(0)
dino_fb.rect(0, 12, 4, 4, 1)
dino_fb.rect(4, 8, 4, 8, 1)
dino_fb.rect(8, 4, 4, 4, 1)
dino_fb.pixel(12, 6, 1)
dino_fb.line(3, 10, 0, 8, 1)

# 恐龙跳跃
dino_jump_fb = framebuf.FrameBuffer(bytearray(32), 16, 16, framebuf.MONO_HLSB)
dino_jump_fb.fill(0)
dino_jump_fb.rect(0, 12, 4, 4, 1)
dino_jump_fb.rect(4, 8, 4, 8, 1)
dino_jump_fb.rect(8, 4, 4, 4, 1)
dino_jump_fb.pixel(12, 6, 0)
dino_jump_fb.pixel(11, 5, 1)
dino_jump_fb.line(3, 10, 0, 8, 1)

# 仙人掌
cactus1_fb = framebuf.FrameBuffer(bytearray(16), 8, 16, framebuf.MONO_HLSB)
cactus1_fb.fill(0)
cactus1_fb.rect(2, 0, 4, 16, 1)

cactus2_fb = framebuf.FrameBuffer(bytearray(32), 16, 16, framebuf.MONO_HLSB)
cactus2_fb.fill(0)
cactus2_fb.rect(2, 0, 4, 16, 1)
cactus2_fb.rect(10, 4, 4, 12, 1)

cactus3_fb = framebuf.FrameBuffer(bytearray(48), 24, 16, framebuf.MONO_HLSB)
cactus3_fb.fill(0)
cactus3_fb.rect(2, 0, 4, 16, 1)
cactus3_fb.rect(10, 4, 4, 12, 1)
cactus3_fb.rect(18, 2, 4, 14, 1)

# 翼龙（2帧简化）
pterosaur_fb1 = framebuf.FrameBuffer(bytearray(16), 16, 8, framebuf.MONO_HLSB)
pterosaur_fb1.fill(0)
pterosaur_fb1.ellipse(8, 4, 6, 3, 1)
pterosaur_fb1.line(2, 3, 0, 0, 1)
pterosaur_fb1.line(2, 5, 0, 8, 1)
pterosaur_fb1.line(14, 3, 16, 0, 1)
pterosaur_fb1.line(14, 5, 16, 8, 1)
pterosaur_fb1.pixel(6, 4, 1)

pterosaur_fb2 = framebuf.FrameBuffer(bytearray(16), 16, 8, framebuf.MONO_HLSB)
pterosaur_fb2.fill(0)
pterosaur_fb2.ellipse(8, 4, 6, 3, 1)
pterosaur_fb2.line(4, 3, 1, 2, 1)
pterosaur_fb2.line(4, 5, 1, 6, 1)
pterosaur_fb2.line(12, 3, 15, 2, 1)
pterosaur_fb2.line(12, 5, 15, 6, 1)
pterosaur_fb2.pixel(6, 4, 1)

pterosaur_frame = 0
pterosaur_animation_counter = 0

def load_high_score():
    global high_score
    try:
        with open('dino_data.json', 'r') as f:
            data = json.load(f)
            high_score = data.get('high_score', 0)
    except:
        high_score = 0

def save_high_score():
    global high_score, distance
    if distance > high_score:
        high_score = distance
        try:
            with open('dino_data.json', 'w') as f:
                json.dump({'high_score': high_score}, f)
        except:
            pass

def show_difficulty_menu():
    oled.fill(0)
    oled.text("SELECT MODE", 24, 5)
    oled.text("SINGLE: SWITCH", 12, 20)
    oled.text("DOUBLE: CONFIRM", 12, 30)
    
    if difficulty == 1:
        oled.text("> EASY <", 44, 45)
    elif difficulty == 2:
        oled.text("> HARD <", 44, 45)
    elif difficulty == 3:
        oled.text("> SPEEDRUN <", 36, 45)
    else:
        oled.text("> NONE <", 44, 45)
    
    if difficulty == 1:
        oled.text("Normal", 48, 55)
    elif difficulty == 2:
        oled.text("Hard + Night", 40, 55)
    elif difficulty == 3:
        oled.text("Pterosaur Rush!", 32, 55)
    
    oled.show()

def show_start_screen():
    oled.fill(0)
    oled.text("DINO GAME", 32, 10)
    oled.text("Press to START", 20, 30)
    
    if difficulty == 1:
        oled.text("EASY", 52, 45)
    elif difficulty == 2:
        oled.text("HARD", 52, 45)
    elif difficulty == 3:
        oled.text("SPEEDRUN", 44, 45)
    
    oled.text("9999m to WIN", 28, 55)
    oled.show()

def show_game_over():
    global game_over_flag
    save_high_score()
    oled.fill(0)
    oled.text("GAME OVER", 24, 10)
    oled.text(str(distance) + "m", 48, 25)
    oled.text("BEST:" + str(high_score) + "m", 28, 35)
    oled.text("Press to retry", 20, 50)
    oled.show()
    game_over_flag = True

def show_win_screen():
    global game_win_flag
    save_high_score()
    oled.fill(0)
    oled.text("YOU WIN!", 32, 10)
    oled.text("9999m", 48, 25)
    oled.text("BEST:" + str(high_score) + "m", 28, 35)
    oled.text("Press to retry", 20, 50)
    oled.show()
    game_win_flag = True

def draw_ground():
    global ground_offset
    ground_offset = (ground_offset + 1) & 15
    # 简化地面绘制
    oled.hline(0, dino_y_ground + 8, 128, 1)
    if ground_offset < 8:
        oled.hline(ground_offset, dino_y_ground + 8, 8, 0)

def update_dino():
    global dino_y, is_jumping, jump_velocity
    
    if is_jumping:
        dino_y += jump_velocity
        jump_velocity += dino_gravity
        if dino_y >= dino_y_ground:
            dino_y = dino_y_ground
            is_jumping = False
            jump_velocity = 0.0

def check_collision():
    dino_left = dino_x
    dino_right = dino_x + 16
    dino_top = int(dino_y)
    dino_bottom = int(dino_y) + 16
    
    for obs in obstacles:
        if (dino_right > obs['x'] and dino_left < obs['x'] + obs['width'] and
            dino_bottom > obs['y'] and dino_top < obs['y'] + obs['height']):
            return True
    return False

def jump():
    global is_jumping, jump_velocity
    if not is_jumping and game_started and not game_over_flag and not game_win_flag:
        is_jumping = True
        jump_velocity = dino_jump_velocity

def generate_obstacle():
    if obstacles:
        return
    
    if difficulty == 3:  # SPEEDRUN模式
        # 80%概率出翼龙，20%概率出仙人掌
        if random.randint(0, 4) <= 3:
            # 翼龙从右侧快速飞来
            obstacle = {
                'type': 'pterosaur',
                'x': 128,
                'width': 16,
                'height': 8,
                'y': pterosaur_y_flying,
                'speed_boost': 1.5  # 速度加成
            }
        else:
            cactus_count = random.randint(1, 2)
            if cactus_count == 1:
                obstacle = {
                    'type': 'cactus',
                    'x': 128,
                    'width': 8,
                    'height': 16,
                    'y': dino_y_ground + 8,
                    'cactus_count': 1
                }
            else:
                obstacle = {
                    'type': 'cactus',
                    'x': 128,
                    'width': 16,
                    'height': 16,
                    'y': dino_y_ground + 8,
                    'cactus_count': 2
                }
        obstacles.append(obstacle)
    else:
        # 原有逻辑
        rand_type = random.randint(0, 3)
        if rand_type <= 2:
            cactus_count = random.randint(1, 3)
            if cactus_count == 1:
                obstacle = {
                    'type': 'cactus',
                    'x': 128,
                    'width': 8,
                    'height': 16,
                    'y': dino_y_ground + 8,
                    'cactus_count': 1
                }
            elif cactus_count == 2:
                obstacle = {
                    'type': 'cactus',
                    'x': 128,
                    'width': 16,
                    'height': 16,
                    'y': dino_y_ground + 8,
                    'cactus_count': 2
                }
            else:
                obstacle = {
                    'type': 'cactus',
                    'x': 128,
                    'width': 24,
                    'height': 16,
                    'y': dino_y_ground + 8,
                    'cactus_count': 3
                }
        else:
            obstacle = {
                'type': 'pterosaur',
                'x': 128,
                'width': 16,
                'height': 8,
                'y': pterosaur_y_flying
            }
        obstacles.append(obstacle)

def move_obstacles():
    for obs in obstacles[:]:
        # 根据模式调整速度
        if obs.get('speed_boost', 0):
            obs['x'] -= obstacle_speed * 2.0  # SPEEDRUN模式翼龙更快
        elif difficulty == 3 and obs['type'] == 'pterosaur':
            obs['x'] -= obstacle_speed * 1.8
        elif obs['type'] == 'pterosaur':
            if difficulty == 1:
                obs['x'] -= obstacle_speed * 0.8
            else:
                obs['x'] -= obstacle_speed * 1.3
        else:
            obs['x'] -= obstacle_speed
        
        if obs['x'] + obs['width'] < 0:
            obstacles.remove(obs)

def update_distance():
    global distance_counter, distance, game_started, game_win_flag
    
    distance_counter += 1
    if distance_counter >= 6:
        distance_counter = 0
        distance += 1
        if distance >= 9999 and not game_win_flag:
            game_started = False
            show_win_screen()

def update_day_night_cycle():
    global day_night_cycle
    if difficulty == 2:  # 只有HARD模式有昼夜
        cycle_stage = (distance // cycle_distance) % 2
        day_night_cycle = 1 if cycle_stage == 1 else 0
    else:
        day_night_cycle = 0

def draw_sky_effects():
    if day_night_cycle == 1:
        # 夜晚（简化星星）
        for i in range(10):
            oled.pixel((i * 37 + distance) & 127, (i * 23) & 63, 1)
        oled.ellipse(110, 5, 4, 4, 1)
        oled.pixel(108, 4, 0)
        oled.text("N", 0, 0)
    else:
        if difficulty != 3:  # SPEEDRUN模式不显示太阳
            oled.ellipse(115, 5, 4, 4, 1)
        oled.text("D", 0, 0)

def display_distance():
    oled.fill_rect(85, 0, 43, 16, 0)
    if distance >= 9999:
        oled.text("9999m", 95, 0)
    else:
        oled.text(str(distance) + "m", 100, 0)
    oled.text(str(high_score), 85, 8)

def update_animation():
    global pterosaur_animation_counter, pterosaur_frame
    
    has_pterosaur = False
    for obs in obstacles:
        if obs['type'] == 'pterosaur':
            has_pterosaur = True
            break
    
    if has_pterosaur:
        pterosaur_animation_counter += 1
        if pterosaur_animation_counter >= 8:
            pterosaur_animation_counter = 0
            pterosaur_frame = 1 - pterosaur_frame
    else:
        pterosaur_frame = 0

def reset_game():
    global game_started, game_over_flag, game_win_flag, distance, obstacles
    global dino_y, is_jumping, jump_velocity, obstacle_speed, frame_counter
    global distance_counter, day_night_cycle
    
    game_started = True
    game_over_flag = False
    game_win_flag = False
    distance = 0
    obstacles.clear()
    dino_y = dino_y_ground
    is_jumping = False
    jump_velocity = 0.0
    
    if difficulty == 1:
        obstacle_speed = 4
    elif difficulty == 2:
        obstacle_speed = 6
    else:  # SPEEDRUN
        obstacle_speed = 7  # 更快的基础速度
    
    frame_counter = 0
    distance_counter = 0
    day_night_cycle = 0
    
    oled.fill(0)
    oled.show()

def button_handler(pin):
    global selecting_difficulty, difficulty, game_started, game_over_flag
    global game_win_flag, button_press_count, last_button_time
    
    time.sleep_ms(20)  # 减少防抖时间
    if pin.value() == 0:
        current_time = time.ticks_ms()
        
        if selecting_difficulty:
            if current_time - last_button_time < 300:
                if difficulty in [1, 2, 3]:
                    selecting_difficulty = False
                    show_start_screen()
                    button_press_count = 0
                    last_button_time = 0
            else:
                if difficulty == 0:
                    difficulty = 1
                elif difficulty == 1:
                    difficulty = 2
                elif difficulty == 2:
                    difficulty = 3
                elif difficulty == 3:
                    difficulty = 1
                show_difficulty_menu()
                button_press_count = 1
                last_button_time = current_time
        else:
            if not game_started and not game_over_flag and not game_win_flag:
                reset_game()
            elif game_over_flag or game_win_flag:
                reset_game()
            else:
                jump()

# 加载高分
load_high_score()

# 显示难度菜单
selecting_difficulty = True
show_difficulty_menu()

# 设置按钮中断
button.irq(trigger=Pin.IRQ_FALLING, handler=button_handler)

# 主循环
while True:
    if game_started and not game_over_flag and not game_win_flag:
        update_distance()
        update_day_night_cycle()
        update_dino()
        
        # 障碍物生成
        frame_counter += 1
        if difficulty == 3:  # SPEEDRUN模式生成更频繁
            gen_interval = random.randint(20, 50)
        elif difficulty == 1:
            gen_interval = random.randint(60, 120)
        else:
            gen_interval = random.randint(40, 80)
        
        if not obstacles and frame_counter > gen_interval:
            generate_obstacle()
            frame_counter = 0
        
        move_obstacles()
        
        # 速度调整
        if difficulty == 1:
            obstacle_speed = min(4 + distance // 200, 8)
        elif difficulty == 2:
            obstacle_speed = min(6 + distance // 150, 12)
        else:  # SPEEDRUN
            obstacle_speed = min(7 + distance // 100, 15)  # 更快
        
        update_animation()
        
        if check_collision():
            game_started = False
            show_game_over()
            continue
        
        # 渲染
        oled.fill(0)
        draw_sky_effects()
        draw_ground()
        
        # 绘制恐龙
        if is_jumping:
            oled.blit(dino_jump_fb, dino_x, int(dino_y))
        else:
            oled.blit(dino_fb, dino_x, int(dino_y))
        
        # 绘制障碍物
        for obs in obstacles:
            if obs['type'] == 'cactus':
                if obs['cactus_count'] == 1:
                    oled.blit(cactus1_fb, int(obs['x']), obs['y'])
                elif obs['cactus_count'] == 2:
                    oled.blit(cactus2_fb, int(obs['x']), obs['y'])
                else:
                    oled.blit(cactus3_fb, int(obs['x']), obs['y'])
            else:
                oled.blit(pterosaur_fb1 if pterosaur_frame else pterosaur_fb2, 
                         int(obs['x']), obs['y'])
        
        display_distance()
        oled.show()
        
        # 固定帧率减少卡顿
        time.sleep_ms(12)
    else:
        time.sleep_ms(50)