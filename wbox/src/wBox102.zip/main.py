"""
wBox Game Launcher for ESP32 + SSD1306
Icon: Z
Name: wBox
Version: 1.0.2
Author: Zkwei
Button: GPIO21 (Short press = select, Long press 300ms = switch/back)
OLED: SDA=8, SCL=9
"""

import machine
import ssd1306
import sys
import time
import gc

# ================== 硬件初始化 ==================
# I2C for OLED (SDA=8, SCL=9) 
i2c = machine.I2C(0, sda=machine.Pin(8), scl=machine.Pin(9), freq=400000)

# 检测I2C设备
print("Scanning I2C bus...")
devices = i2c.scan()
if not devices:
    print("Error: No I2C device found!")
    sys.exit(1)
print("I2C devices found:", [hex(dev) for dev in devices])

# 初始化OLED (128x64)
try:
    oled = ssd1306.SSD1306_I2C(128, 64, i2c)
except Exception as e:
    print("OLED init failed:", e)
    sys.exit(1)

# 按键初始化 (GPIO21, 内部上拉) 
btn = machine.Pin(21, machine.Pin.IN, machine.Pin.PULL_UP)

# LED指示灯 (可选，用板载LED或自定义)
led = machine.Pin(2, machine.Pin.OUT)  # 大多数ESP32开发板板载LED在GPIO2


# ================== 辅助函数 ==================
def clear_screen():
    """清空屏幕"""
    oled.fill(0)
    oled.show()


def show_message(lines, wait=2):
    """
    显示多行消息
    lines: list of strings, 最多4行
    wait: 显示时间(秒)
    """
    clear_screen()
    y = 0
    for line in lines[:4]:  # 最多显示4行
        oled.text(line, 0, y)
        y += 12
    oled.show()
    time.sleep(wait)


def show_error(msg):
    """
    显示错误界面
    """
    clear_screen()
    oled.fill(0)
    oled.text("ERROR!", 40, 20)
    oled.text(msg[:16], 0, 35)
    if len(msg) > 16:
        oled.text(msg[16:32], 0, 47)
    oled.show()
    time.sleep(2)


def list_files(directory="/"):
    """
    扫描flash中的文件
    返回文件名字典
    """
    import uos
    files = {}
    try:
        for item in uos.ilistdir(directory):
            if item[1] == 0x8000:  # 文件类型
                files[item[0]] = True
    except Exception as e:
        print("File scan error:", e)
    return files


def run_game(script_name):
    """
    尝试导入并运行游戏脚本
    """
    clear_screen()
    oled.text("Loading...", 40, 28)
    oled.show()
    time.sleep(0.5)
    
    try:
        # 动态导入游戏模块
        game = __import__(script_name.replace(".py", ""))
        # 如果游戏有main函数则调用
        if hasattr(game, 'main'):
            game.main()
        else:
            # 否则直接重新执行游戏代码
            with open(script_name, 'r') as f:
                exec(f.read(), {'__name__': '__main__'})
        return True
    except Exception as e:
        show_error(str(e)[:32])
        return False


# ================== 按键处理 ==================
class Button:
    """
    按键处理类，支持长按/短按检测 
    """
    def __init__(self, pin, long_press_ms=300, debounce_ms=30):
        self.pin = pin
        self.long_press_ms = long_press_ms
        self.debounce_ms = debounce_ms
        self._pressed = False
        self._press_time = 0
        self._last_event = 0
        
    def update(self):
        """
        更新按键状态，返回：
        0: 无事件
        1: 短按
        2: 长按
        """
        current = self.pin.value() == 0  # 按下为低电平（PULL_UP）
        now = time.ticks_ms()
        
        # 消抖
        if current != self._pressed:
            if time.ticks_diff(now, self._last_event) > self.debounce_ms:
                self._pressed = current
                self._last_event = now
                if current:  # 刚按下
                    self._press_time = now
                else:  # 刚释放
                    press_duration = time.ticks_diff(now, self._press_time)
                    if press_duration < self.long_press_ms:
                        return 1  # 短按
                    else:
                        return 2  # 长按
        return 0


# ================== 启动动画 ==================
def boot_animation():
    """
    显示wBox启动动画
    图标Z + 进度条效果
    """
    # 清屏
    oled.fill(0)
    
    # 绘制大Z图标 (约40x40像素)
    # Z字形: 左上到右上，斜线到左下，左下到右下
    oled.fill_rect(44, 8, 40, 40, 1)  # 背景方框
    oled.fill_rect(46, 10, 36, 36, 0)  # 内部清空
    
    # 画Z的三条线
    # 顶部横线
    oled.fill_rect(50, 14, 28, 6, 1)
    # 斜线 (使用像素点阵)
    for i in range(24):
        oled.pixel(50 + i, 20 + i, 1)
    # 底部横线
    oled.fill_rect(50, 44, 28, 6, 1)
    
    oled.text("wBox", 50, 0)
    oled.show()
    time.sleep(1)
    
    # 进度条动画
    for i in range(0, 101, 10):
        oled.fill_rect(0, 56, int(128 * i / 100), 6, 1)
        oled.show()
        time.sleep(0.03)
    
    clear_screen()
    oled.text("wBox Launcher", 25, 20)
    oled.text("v1.0.2", 50, 35)
    oled.text("(c) Zkwei", 40, 50)
    oled.show()
    time.sleep(1.5)


# ================== 主菜单 ==================
class Menu:
    def __init__(self, items):
        self.items = items
        self.selected = 0
        self.last_key = 0
        
    def draw(self):
        clear_screen()
        oled.text("==== wBox ====", 20, 0)
        y = 16
        for i, item in enumerate(self.items):
            prefix = ">" if i == self.selected else " "
            # 限制显示长度
            display_text = item[:15] if len(item) <= 15 else item[:12] + "..."
            oled.text(prefix + " " + display_text, 0, y)
            y += 12
        oled.text("Short:Run Long:Switch", 0, 56)
        oled.show()
        
    def next(self):
        self.selected = (self.selected + 1) % len(self.items)
        self.draw()
        
    def get_selected(self):
        return self.items[self.selected]


# ================== 主程序 ==================
def main():
    """
    主函数
    """
    # 显示启动动画
    boot_animation()
    
    # 扫描Flash中的游戏文件 
    show_message(["Scanning Flash...", "Looking for games"], 0.5)
    
    files = list_files("/")
    available_games = []
    
    # 检查游戏文件
    game_files = ["dino.py", "emolp.py"]
    game_names = {
        "dino.py": "Dino 1.0",
        "emolp.py": "Emolp 1.0"
    }
    
    for game_file in game_files:
        if game_file in files:
            available_games.append(game_names[game_file])
    
    # 始终添加About选项
    available_games.append("About")
    
    if not available_games or (len(available_games) == 1 and available_games[0] == "About"):
        show_error("No game files found!\nPlease buy a game")
        # 即使没有游戏也显示菜单，但只有About
        print("Warning: No game files found")
    
    # 初始化菜单
    menu = Menu(available_games)
    btn_handler = Button(btn, long_press_ms=300)  # 长按300ms切换 ✅
    
    # 主循环
    last_draw = 0
    selected_item = None
    
    while True:
        # 处理按键
        event = btn_handler.update()
        
        if event == 1:  # 短按 - 启动选中的游戏或显示About
            selected = menu.get_selected()
            if selected == "About":
                # 显示About信息
                show_message(["Z wBox Launcher", "v1.0.2", "(c) Zkwei 2024-2029", "Official wBox"], 3)
                menu.draw()  # 返回后刷新菜单
            else:
                # 启动游戏 - 根据显示名称找到实际文件名
                actual_file = None
                for fname, dname in game_names.items():
                    if dname == selected:
                        actual_file = fname
                        break
                
                if actual_file:
                    # 闪烁LED表示启动
                    led.value(1)
                    time.sleep(0.1)
                    led.value(0)
                    
                    # 运行游戏
                    run_game(actual_file)
                    
                    # 游戏返回后重新初始化显示
                    try:
                        oled.init_display()
                        time.sleep(0.5)
                    except:
                        pass
                    menu.draw()
                else:
                    show_error("File not found", 1)
                    menu.draw()
                    
        elif event == 2:  # 长按(300ms) - 切换菜单项
            menu.next()
            
        # 防止菜单卡死，定期刷新显示（万一意外清屏）
        if time.ticks_diff(time.ticks_ms(), last_draw) > 5000:
            menu.draw()
            last_draw = time.ticks_ms()
            
        time.sleep(0.05)


# 启动入口
if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        clear_screen()
        oled.text("Shutdowning...", 40, 28)
        oled.show()
        time.sleep(1)
        clear_screen()
    except Exception as e:
        show_error(str(e)[:32])
        print("Fatal error:", e)