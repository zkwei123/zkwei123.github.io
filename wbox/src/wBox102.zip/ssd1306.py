from micropython import const
import framebuf
import math

__version__ = '1.0.2'
__author__ = 'Teeraphat Kullanankanjana'

SET_DISP = const(0xae)
SET_MEM_ADDR = const(0x20)
SET_DISP_START_LINE = const(0x40)
SET_SEG_REMAP = const(0xa0)
SET_MUX_RATIO = const(0xa8)
SET_COM_OUT_DIR = const(0xc0)
SET_DISP_OFFSET = const(0xd3)
SET_COM_PIN_CFG = const(0xda)
SET_DISP_CLK_DIV = const(0xd5)
SET_PRECHARGE = const(0xd9)
SET_VCOM_DESEL = const(0xdb)
SET_ENTIRE_ON = const(0xa4)
SET_NORM_INV = const(0xa6)
SET_CHARGE_PUMP = const(0x8d)
SET_COL_ADDR = const(0x21)
SET_PAGE_ADDR = const(0x22)
SET_CONTRAST = const(0x81)


class SSD1306:
    def __init__(self, width, height, external_vcc):
        self.width = width
        self.height = height
        self.external_vcc = external_vcc
        self.pages = height // 8
        self.buffer = bytearray(self.pages * self.width)
        self.framebuf = framebuf.FrameBuffer(self.buffer, self.width, self.height, framebuf.MONO_VLSB)

        self.fill = self.framebuf.fill
        self.pixel = self.framebuf.pixel
        self.hline = self.framebuf.hline
        self.vline = self.framebuf.vline
        self.line = self.framebuf.line
        self.rect = self.framebuf.rect
        self.fill_rect = self.framebuf.fill_rect
        self.text = self.framebuf.text
        self.scroll = self.framebuf.scroll
        self.blit = self.framebuf.blit

        self.init_display()

    def init_display(self):
        for cmd in (
            SET_DISP | 0x00,
            SET_MEM_ADDR, 0x00,
            SET_DISP_START_LINE | 0x00,
            SET_SEG_REMAP | 0x01,
            SET_MUX_RATIO, self.height - 1,
            SET_COM_OUT_DIR | 0x08,
            SET_DISP_OFFSET, 0x00,
            SET_COM_PIN_CFG, 0x02 if self.height == 32 else 0x12,
            SET_DISP_CLK_DIV, 0x80,
            SET_PRECHARGE, 0x22 if self.external_vcc else 0xf1,
            SET_VCOM_DESEL, 0x30,
            SET_CONTRAST, 0xff,
            SET_ENTIRE_ON,
            SET_NORM_INV,
            SET_CHARGE_PUMP, 0x10 if self.external_vcc else 0x14,
            SET_DISP | 0x01
        ):
            self.write_cmd(cmd)
        self.fill(0)
        self.show()

    def poweroff(self):
        self.write_cmd(SET_DISP | 0x00)

    def poweron(self):
        self.write_cmd(SET_DISP | 0x01)

    def contrast(self, contrast):
        self.write_cmd(SET_CONTRAST)
        self.write_cmd(contrast)

    def invert(self, invert):
        self.write_cmd(SET_NORM_INV | (invert & 1))

    def rotate(self, rotate):
        self.write_cmd(SET_COM_OUT_DIR | ((rotate & 1) << 3))
        self.write_cmd(SET_SEG_REMAP | (rotate & 1))

    def show(self):
        x0 = 0
        x1 = self.width - 1
        if self.width == 64:
            x0 += 32
            x1 += 32
        self.write_cmd(SET_COL_ADDR)
        self.write_cmd(x0)
        self.write_cmd(x1)
        self.write_cmd(SET_PAGE_ADDR)
        self.write_cmd(0)
        self.write_cmd(self.pages - 1)
        self.write_data(self.buffer)

    def triangle(self, x0, y0, x1, y1, x2, y2, color, fill=False):
        if fill:
            min_x = min(x0, x1, x2)
            max_x = max(x0, x1, x2)
            min_y = min(y0, y1, y2)
            max_y = max(y0, y1, y2)

            for y in range(min_y, max_y + 1):
                crossings = []
                if (y0 <= y <= y1) or (y1 <= y <= y0):
                    crossings.append(self._get_intersection(x0, y0, x1, y1, y))
                if (y1 <= y <= y2) or (y2 <= y <= y1):
                    crossings.append(self._get_intersection(x1, y1, x2, y2, y))
                if (y0 <= y <= y2) or (y2 <= y <= y0):
                    crossings.append(self._get_intersection(x0, y0, x2, y2, y))

                crossings.sort()
                for x in range(crossings[0], crossings[1] + 1):
                    self.pixel(x, y, color)
        else:
            self.line(x0, y0, x1, y1, color)
            self.line(x1, y1, x2, y2, color)
            self.line(x2, y2, x0, y0, color)

    def _get_intersection(self, x0, y0, x1, y1, y):
        if y1 == y0:
            return min(x0, x1)
        return int(x0 + (x1 - x0) * (y - y0) / (y1 - y0))

    def circle(self, cx, cy, r, color, fill=False):
        if fill:
            for y in range(cy - r, cy + r + 1):
                dx = int((r ** 2 - (y - cy) ** 2) ** 0.5)
                for x in range(cx - dx, cx + dx + 1):
                    self.pixel(x, y, color)
        else:
            x = 0
            y = r
            p = 3 - 2 * r

            while x <= y:
                self.pixel(cx + x, cy + y, color)
                self.pixel(cx - x, cy + y, color)
                self.pixel(cx + x, cy - y, color)
                self.pixel(cx - x, cy - y, color)
                self.pixel(cx + y, cy + x, color)
                self.pixel(cx - y, cy + x, color)
                self.pixel(cx + y, cy - x, color)
                self.pixel(cx - y, cy - x, color)

                if p < 0:
                    p = p + 4 * x + 6
                else:
                    p = p + 4 * (x - y) + 10
                    y -= 1
                x += 1

    def polygon(self, points, color, fill=False):
        num_points = len(points)

        for i in range(num_points):
            x0, y0 = points[i]
            x1, y1 = points[(i + 1) % num_points]
            self.line(x0, y0, x1, y1, color)

        if fill:
            min_y = min(points, key=lambda p: p[1])[1]
            max_y = max(points, key=lambda p: p[1])[1]

            for y in range(min_y, max_y + 1):
                intersections = []
                for i in range(num_points):
                    x0, y0 = points[i]
                    x1, y1 = points[(i + 1) % num_points]

                    if (y0 <= y < y1) or (y1 <= y < y0):
                        x_intersection = x0 + (y - y0) * (x1 - x0) / (y1 - y0)
                        intersections.append(int(x_intersection))

                intersections.sort()
                for i in range(0, len(intersections), 2):
                    x_start = intersections[i]
                    x_end = intersections[i + 1]
                    for x in range(x_start, x_end + 1):
                        self.pixel(x, y, color)

    def parallelogram(self, x1, y1, x2, y2, dx1, dy1, dx2, dy2, color, fill=False):
        x3, y3 = x1 + dx1, y1 + dy1
        x4, y4 = x2 + dx2, y2 + dy2

        self.line(x1, y1, x2, y2, color)
        self.line(x2, y2, x4, y4, color)
        self.line(x4, y4, x3, y3, color)
        self.line(x3, y3, x1, y1, color)

        if fill:
            min_y = min(y1, y2, y3, y4)
            max_y = max(y1, y2, y3, y4)

            for y in range(min_y, max_y + 1):
                intersections = []
                self._find_intersections(x1, y1, x2, y2, dx1, dy1, y, intersections)
                self._find_intersections(x2, y2, x4, y4, dx2, dy2, y, intersections)
                self._find_intersections(x4, y4, x3, y3, -dx1, -dy1, y, intersections)
                self._find_intersections(x3, y3, x1, y1, -dx2, -dy2, y, intersections)

                intersections.sort()
                for i in range(0, len(intersections), 2):
                    x_start = intersections[i]
                    x_end = intersections[i + 1]
                    for x in range(x_start, x_end + 1):
                        self.pixel(x, y, color)

    def trapezium(self, x1, y1, x2, y2, x3, y3, x4, y4, color, fill=False):
        self.line(x1, y1, x2, y2, color)
        self.line(x2, y2, x3, y3, color)
        self.line(x3, y3, x4, y4, color)
        self.line(x4, y4, x1, y1, color)

        if fill:
            min_y = min(y1, y2, y3, y4)
            max_y = max(y1, y2, y3, y4)

            for y in range(min_y, max_y + 1):
                intersections = []
                self._find_intersections(x1, y1, x2, y2, x3, y3, y, intersections)
                self._find_intersections(x2, y2, x3, y3, x4, y4, y, intersections)
                self._find_intersections(x3, y3, x4, y4, x1, y1, y, intersections)
                self._find_intersections(x4, y4, x1, y1, x2, y2, y, intersections)

                intersections.sort()
                for i in range(0, len(intersections), 2):
                    x_start = intersections[i]
                    x_end = intersections[i + 1]
                    for x in range(x_start, x_end + 1):
                        self.pixel(x, y, color)

    def ellipse(self, cx, cy, rx, ry, color, fill=False):
        if fill:
            for y in range(cy - ry, cy + ry + 1):
                dx = int(rx * (1 - ((y - cy) ** 2 / ry ** 2)) ** 0.5)
                for x in range(cx - dx, cx + dx + 1):
                    self.pixel(x, y, color)
        else:
            x = 0
            y = ry
            p1 = ry * ry - rx * rx * ry + 0.25 * rx * rx
            dx = 2 * ry * ry * x
            dy = 2 * rx * rx * y

            while dx < dy:
                self.pixel(cx + x, cy + y, color)
                self.pixel(cx - x, cy + y, color)
                self.pixel(cx + x, cy - y, color)
                self.pixel(cx - x, cy - y, color)

                x += 1
                dx += 2 * ry * ry
                if p1 < 0:
                    p1 += dx + ry * ry
                else:
                    y -= 1
                    dy -= 2 * rx * rx
                    p1 += dx - dy + ry * ry

            p2 = ry * ry * (x + 0.5) ** 2 + rx * rx * (y - 1) ** 2 - rx * rx * ry * ry
            while y >= 0:
                self.pixel(cx + x, cy + y, color)
                self.pixel(cx - x, cy + y, color)
                self.pixel(cx + x, cy - y, color)
                self.pixel(cx - x, cy - y, color)

                y -= 1
                dy -= 2 * rx * rx
                if p2 > 0:
                    p2 += rx * rx - dy
                else:
                    x += 1
                    dx += 2 * ry * ry
                    p2 += dx - dy + rx * rx

    def _find_intersections(self, x1, y1, x2, y2, dx, dy, y, intersections):
        if (y1 <= y < y2) or (y2 <= y < y1):
            x_intersection = x1 + (y - y1) * (x2 - x1) / (y2 - y1)
            intersections.append(int(x_intersection))

    def round_rect(self, x, y, w, h, color, filled=False, radius=0):
        if radius > 0:
            self.arc(x + radius, y + radius, radius, 180, 270, color)
            self.arc(x + w - radius - 1, y + radius, radius, 270, 360, color)
            self.arc(x + radius, y + h - radius - 1, radius, 90, 180, color)
            self.arc(x + w - radius - 1, y + h - radius - 1, radius, 0, 90, color)

        if filled:
            self.fill_rect(x + radius, y, w - 2 * radius, h, color)
            self.fill_rect(x + radius, y + h - 1, w - 2 * radius, -h + 2 * radius, color)
            self.fill_rect(x, y + radius, w, h - 2 * radius, color)
            self.fill_rect(x + w - 1, y + radius, -w + 2 * radius, h - 2 * radius, color)
        else:
            self.line(x + radius, y, x + w - radius - 1, y, color)
            self.line(x + radius, y + h - 1, x + w - radius - 1, y + h - 1, color)
            self.line(x, y + radius, x, y + h - radius - 1, color)
            self.line(x + w - 1, y + radius, x + w - 1, y + h - radius - 1, color)

    def arc(self, cx, cy, r, start_angle, end_angle, color):
        start_angle = math.radians(start_angle)
        end_angle = math.radians(end_angle)

        step = 1 / r
        for angle in range(int(start_angle * 180 / math.pi), int(end_angle * 180 / math.pi)):
            angle_rad = angle * math.pi / 180
            x = int(cx + r * math.cos(angle_rad))
            y = int(cy + r * math.sin(angle_rad))
            self.pixel(x, y, color)

    def write_cmd(self, cmd):
        raise NotImplementedError

    def write_data(self, buf):
        raise NotImplementedError


class SSD1306_I2C(SSD1306):
    def __init__(self, width, height, i2c, addr=0x3c, external_vcc=False):
        self.i2c = i2c
        self.addr = addr
        self.temp = bytearray(2)
        super().__init__(width, height, external_vcc)

    def write_cmd(self, cmd):
        self.temp[0] = 0x80
        self.temp[1] = cmd
        self.i2c.writeto(self.addr, self.temp)

    def write_data(self, buf):
        self.i2c.writeto_mem(self.addr, 0x40, buf)


class SSD1306_SPI(SSD1306):
    def __init__(self, width, height, spi, dc, res, cs, external_vcc=False):
        self.spi = spi
        self.dc = dc
        self.res = res
        self.cs = cs
        self.rate = 10 * 1024 * 1024
        dc.init(dc.OUT, value=0)
        res.init(res.OUT, value=0)
        cs.init(cs.OUT, value=1)
        super().__init__(width, height, external_vcc)

    def write_cmd(self, cmd):
        self.spi.init(baudrate=self.rate, polarity=0, phase=0)
        self.cs.high()
        self.dc.low()
        self.cs.low()
        self.spi.write(bytearray([cmd]))
        self.cs.high()

    def write_data(self, buf):
        self.spi.init(baudrate=self.rate, polarity=0, phase=0)
        self.cs.high()
        self.dc.high()
        self.cs.low()
        self.spi.write(buf)
        self.cs.high()